# AL MISBAH TRADING - POS System

A modern, web-based Point of Sale (POS) system for AL MISBAH TRADING. This system provides comprehensive features for managing sales, inventory, quotations, delivery notes, and generating reports.

## Features

- **Point of Sale (POS)**
  - Quick product search and barcode scanning
  - Category-based product filtering
  - Cart management with real-time calculations
  - Multiple payment methods
  - Receipt printing

- **Inventory Management**
  - Product categorization
  - Stock tracking
  - Price management
  - Low stock alerts

- **Quotation System**
  - Create and manage quotations
  - Convert quotations to sales
  - PDF export

- **Delivery Notes**
  - Generate delivery notes
  - Track delivery status
  - Link to sales and quotations

- **Client Management**
  - Customer database
  - Purchase history
  - Contact information

- **Reports**
  - Sales reports
  - Inventory reports
  - Financial summaries
  - Export capabilities

## Project Structure

```
pos-system/
├── css/
│   └── styles.css          # Main stylesheet
├── js/
│   ├── app.js             # Core application logic
│   ├── pos.js            # POS functionality
│   ├── inventory.js      # Inventory management
│   ├── quotation.js      # Quotation system
│   ├── delivery.js       # Delivery notes
│   ├── clients.js        # Client management
│   ├── reports.js        # Reporting system
│   ├── settings.js       # System settings
│   ├── database.js       # Data management
│   ├── config.js         # Configuration
│   └── utils.js          # Utility functions
└── index.html            # Main HTML file
```

## Setup Instructions

1. Clone or download this repository
2. Open `index.html` in a modern web browser
3. Configure your business details in the Settings tab
4. Start using the system

## Browser Compatibility

The system is compatible with modern web browsers:
- Google Chrome (recommended)
- Mozilla Firefox
- Microsoft Edge
- Safari

## Development

To modify or extend the system:

1. CSS styles are in `css/styles.css`
2. JavaScript modules are in the `js/` directory
3. Main HTML structure is in `index.html`

## License

This software is proprietary and confidential. All rights reserved.

## Support

For technical support or feature requests, please contact the development team.
