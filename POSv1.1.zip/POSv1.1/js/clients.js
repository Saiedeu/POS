class ClientManager {
    constructor() {
        console.log('Initializing ClientManager...');
        this.init();
    }

    init() {
        console.log('ClientManager.init() called');
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initializeManager());
        } else {
            this.initializeManager();
        }
    }

    initializeManager() {
        console.log('Initializing manager components');
        this.bindElements();
        this.bindEvents();
        
        if (window.dbManager?.db) {
            console.log('Database already available');
            this.loadClients();
        } else {
            console.log('Waiting for database to be ready...');
            window.addEventListener('database-ready', (event) => {
                console.log('Database is now ready:', event.detail.db);
                this.loadClients();
            });
        }
    }

    bindElements() {
        console.log('Binding elements');
        this.clientTab = document.getElementById('clients');
        if (this.clientTab) {
            this.setupClientUI();
            this.addClientBtn = document.getElementById('add-client-btn');
            this.searchInput = document.getElementById('client-search');
            this.categoryFilter = document.getElementById('category-filter');
            this.statusFilter = document.getElementById('status-filter');
            this.clientTableBody = this.clientTab.querySelector('.client-table tbody');
        }
    }

    bindEvents() {
        console.log('Binding events');
        if (this.addClientBtn) {
            this.addClientBtn.addEventListener('click', () => this.showAddClientModal());
        }
        if (this.searchInput) {
            this.searchInput.addEventListener('input', () => this.filterClients());
        }
        if (this.categoryFilter) {
            this.categoryFilter.addEventListener('change', () => this.filterClients());
        }
        if (this.statusFilter) {
            this.statusFilter.addEventListener('change', () => this.filterClients());
        }

        window.addEventListener('tab-changed', (event) => {
            if (event.detail.tab === 'clients') {
                this.loadClients();
            }
        });
    }

    setupClientUI() {
        console.log('Setting up client UI');
        this.clientTab.innerHTML = `
            <div class="client-container">
                <div class="client-header">
                    <h2>Client Management</h2>
                    <button class="btn btn-primary" id="add-client-btn">
                        <i class="fas fa-plus"></i> Add New Client
                    </button>
                </div>
                <div class="client-controls">
                    <div class="search-box">
                        <input type="text" id="client-search" placeholder="Search clients...">
                    </div>
                    <div class="filters">
                        <select id="category-filter">
                            <option value="">All Categories</option>
                            <option value="regular">Regular</option>
                            <option value="vip">VIP</option>
                            <option value="wholesale">Wholesale</option>
                        </select>
                        <select id="status-filter">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="table-container">
                    <table class="client-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>`;
    }

    async loadClients() {
        console.log('Loading clients');
        try {
            const store = window.dbManager.getStore('clients', 'readonly');
            const request = store.getAll();

            request.onsuccess = () => {
                const clients = request.result;
                console.log('Loaded clients:', clients);
                this.displayClients(clients);
            };

            request.onerror = (event) => {
                console.error('Error loading clients:', event.target.error);
                Utils.showToast('Error loading clients', 'error');
            };
        } catch (error) {
            console.error('Error in loadClients:', error);
            Utils.showToast('Error loading clients', 'error');
        }
    }

    displayClients(clients) {
        if (!this.clientTableBody) {
            console.error('Client table body not found');
            return;
        }

        this.clientTableBody.innerHTML = '';

        if (!clients || clients.length === 0) {
            this.clientTableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="no-items">No clients found</td>
                </tr>`;
            return;
        }

        clients.forEach(client => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${client.name || ''}</td>
                <td>${client.email || ''}</td>
                <td>${client.phone || ''}</td>
                <td><span class="badge category-${client.category?.toLowerCase()}">${client.category || ''}</span></td>
                <td><span class="badge status-${client.status?.toLowerCase()}">${client.status || ''}</span></td>
                <td>
                    <button class="btn btn-icon" onclick="clientManager.viewClient(${client.id})">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-icon" onclick="clientManager.editClient(${client.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-icon" onclick="clientManager.deleteClient(${client.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>`;
            this.clientTableBody.appendChild(row);
        });
    }

    showAddClientModal() {
        console.log('Showing add client modal');
        const modalContent = `
            <form id="add-client-form" class="client-form">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" required>
                        <option value="">Select Category</option>
                        <option value="regular">Regular</option>
                        <option value="vip">VIP</option>
                        <option value="wholesale">Wholesale</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="">Select Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="notes">Notes</label>
                    <textarea id="notes" name="notes" rows="3"></textarea>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Add Client</button>
                    <button type="button" class="btn btn-secondary" onclick="Utils.closeModal()">Cancel</button>
                </div>
            </form>`;

        Utils.openModal('Add New Client', modalContent);

        const form = document.getElementById('add-client-form');
        if (form) {
            form.addEventListener('submit', (e) => this.saveClient(e));
        }
    }

    async saveClient(event) {
        event.preventDefault();
        console.log('Saving client');

        try {
            const form = event.target;
            const formData = new FormData(form);
            const client = {
                name: formData.get('name')?.trim(),
                email: formData.get('email')?.trim(),
                phone: formData.get('phone')?.trim(),
                address: formData.get('address')?.trim(),
                category: formData.get('category'),
                status: formData.get('status'),
                notes: formData.get('notes')?.trim(),
                createdAt: new Date().toISOString()
            };

            // Validate required fields
            if (!client.name || !client.email || !client.phone || !client.category || !client.status) {
                throw new Error('Please fill in all required fields');
            }

            const store = window.dbManager.getStore('clients', 'readwrite');
            const request = store.add(client);

            request.onsuccess = () => {
                Utils.showToast('Client added successfully', 'success');
                Utils.closeModal();
                this.loadClients();
            };

            request.onerror = (event) => {
                console.error('Error saving client:', event.target.error);
                Utils.showToast('Error saving client', 'error');
            };
        } catch (error) {
            console.error('Error in saveClient:', error);
            Utils.showToast(error.message, 'error');
        }
    }

    async filterClients() {
        try {
            const searchTerm = this.searchInput?.value?.toLowerCase() || '';
            const category = this.categoryFilter?.value || '';
            const status = this.statusFilter?.value || '';

            const store = window.dbManager.getStore('clients', 'readonly');
            const request = store.getAll();

            request.onsuccess = () => {
                let clients = request.result;

                // Apply filters
                clients = clients.filter(client => {
                    const matchesSearch = !searchTerm || 
                        client.name?.toLowerCase().includes(searchTerm) ||
                        client.email?.toLowerCase().includes(searchTerm) ||
                        client.phone?.toLowerCase().includes(searchTerm);
                    
                    const matchesCategory = !category || client.category === category;
                    const matchesStatus = !status || client.status === status;

                    return matchesSearch && matchesCategory && matchesStatus;
                });

                this.displayClients(clients);
            };

            request.onerror = (event) => {
                console.error('Error filtering clients:', event.target.error);
                Utils.showToast('Error filtering clients', 'error');
            };
        } catch (error) {
            console.error('Error in filterClients:', error);
            Utils.showToast('Error filtering clients', 'error');
        }
    }

    async viewClient(id) {
        try {
            const store = window.dbManager.getStore('clients', 'readonly');
            const request = store.get(id);

            request.onsuccess = () => {
                const client = request.result;
                if (client) {
                    const modalContent = `
                        <div class="client-details">
                            <div class="detail-row">
                                <label>Name:</label>
                                <span>${client.name || ''}</span>
                            </div>
                            <div class="detail-row">
                                <label>Email:</label>
                                <span>${client.email || ''}</span>
                            </div>
                            <div class="detail-row">
                                <label>Phone:</label>
                                <span>${client.phone || ''}</span>
                            </div>
                            <div class="detail-row">
                                <label>Address:</label>
                                <span>${client.address || ''}</span>
                            </div>
                            <div class="detail-row">
                                <label>Category:</label>
                                <span class="badge category-${client.category?.toLowerCase()}">${client.category || ''}</span>
                            </div>
                            <div class="detail-row">
                                <label>Status:</label>
                                <span class="badge status-${client.status?.toLowerCase()}">${client.status || ''}</span>
                            </div>
                            <div class="detail-row">
                                <label>Notes:</label>
                                <span>${client.notes || ''}</span>
                            </div>
                        </div>`;

                    Utils.openModal('Client Details', modalContent);
                } else {
                    Utils.showToast('Client not found', 'error');
                }
            };

            request.onerror = (event) => {
                console.error('Error viewing client:', event.target.error);
                Utils.showToast('Error viewing client', 'error');
            };
        } catch (error) {
            console.error('Error in viewClient:', error);
            Utils.showToast('Error viewing client', 'error');
        }
    }

    async deleteClient(id) {
        if (!confirm('Are you sure you want to delete this client?')) {
            return;
        }

        try {
            const store = window.dbManager.getStore('clients', 'readwrite');
            const request = store.delete(id);

            request.onsuccess = () => {
                Utils.showToast('Client deleted successfully', 'success');
                this.loadClients();
            };

            request.onerror = (event) => {
                console.error('Error deleting client:', event.target.error);
                Utils.showToast('Error deleting client', 'error');
            };
        } catch (error) {
            console.error('Error in deleteClient:', error);
            Utils.showToast('Error deleting client', 'error');
        }
    }
}

// Initialize client manager
console.log('Setting up client manager...');
window.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Content Loaded - creating client manager');
    window.clientManager = new ClientManager();
});