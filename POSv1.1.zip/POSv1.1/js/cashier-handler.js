// Handle cashier name input and storage
document.addEventListener('DOMContentLoaded', function() {
    const cashierInput = document.getElementById('cashier-name');
    
    // Load saved cashier name if it exists
    const savedCashierName = localStorage.getItem('cashierName');
    if (savedCashierName) {
        cashierInput.value = savedCashierName;
    }

    // Save cashier name when it changes
    cashierInput.addEventListener('input', function() {
        localStorage.setItem('cashierName', this.value);
        updateInvoiceCashier(this.value);
    });

    // Update cashier name in invoice preview
    function updateInvoiceCashier(cashierName) {
        const invoicePreview = document.querySelector('.invoice-preview');
        if (invoicePreview) {
            const cashierElement = invoicePreview.querySelector('.cashier-name');
            if (cashierElement) {
                cashierElement.textContent = cashierName;
            }
        }
    }

    // Function to get current cashier name for invoice printing
    window.getCurrentCashier = function() {
        return cashierInput.value || 'Admin';
    };
});

// Add cashier name to invoice when printing
document.addEventListener('beforeprint', function() {
    const cashierName = getCurrentCashier();
    const invoiceCashier = document.querySelector('.invoice-cashier');
    if (invoiceCashier) {
        invoiceCashier.textContent = cashierName;
    }
});
