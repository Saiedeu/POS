// Initialize IndexedDB for inventory management
let db;
const DB_NAME = 'pos_system';
const STORE_NAME = 'inventory';

const dbPromise = indexedDB.open(DB_NAME, 1);

dbPromise.onupgradeneeded = function(event) {
    db = event.target.result;
    if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
        store.createIndex('code', 'code', { unique: true });
        store.createIndex('name', 'name', { unique: false });
        store.createIndex('category', 'category', { unique: false });
    }
};

dbPromise.onerror = function(event) {
    console.error('Database error:', event.target.error);
};

dbPromise.onsuccess = function(event) {
    db = event.target.result;
    // Dispatch database ready event
    window.dispatchEvent(new Event('database-ready'));
};

// Initialize inventory management
class InventoryManager {
    constructor() {
        console.log('Initializing InventoryManager...');
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }

    init() {
        console.log('InventoryManager.init() called');
        this.bindElements();
        this.bindEvents();
        // Wait for database to be ready
        if (window.dbManager && window.dbManager.isDatabaseReady()) {
            console.log('Database already available');
            this.loadInventory();
        } else {
            console.log('Waiting for database to be ready...');
            window.addEventListener('database-ready', () => {
                console.log('Database is now ready');
                this.loadInventory();
            });
        }
    }

    bindElements() {
        console.log('InventoryManager.bindElements() called');
        // Controls
        this.searchInput = document.querySelector('#inventory-search');
        this.categoryFilter = document.querySelector('#category-filter');
        this.statusFilter = document.querySelector('#status-filter');
        this.addItemBtn = document.querySelector('#add-item-btn');
        this.inventoryTable = document.querySelector('.inventory-table tbody');

        // Debug log elements
        console.log('Elements found:', {
            searchInput: this.searchInput,
            categoryFilter: this.categoryFilter,
            statusFilter: this.statusFilter,
            addItemBtn: this.addItemBtn,
            inventoryTable: this.inventoryTable
        });
    }

    bindEvents() {
        console.log('InventoryManager.bindEvents() called');
        if (this.searchInput) {
            this.searchInput.addEventListener('input', () => this.filterInventory());
        }
        if (this.categoryFilter) {
            this.categoryFilter.addEventListener('change', () => this.filterInventory());
        }
        if (this.statusFilter) {
            this.statusFilter.addEventListener('change', () => this.filterInventory());
        }
        if (this.addItemBtn) {
            console.log('Adding click event to Add Item button');
            this.addItemBtn.addEventListener('click', () => {
                console.log('Add Item button clicked');
                this.showAddItemModal();
            });
        }

        // Listen for tab changes
        window.addEventListener('tab-changed', (event) => {
            console.log('Tab changed event received:', event.detail);
            if (event.detail.tab === 'inventory') {
                console.log('Loading inventory for inventory tab');
                this.loadInventory();
            }
        });
    }

    showAddItemModal() {
        console.log('showAddItemModal() called');
        const modalContent = `
            <form id="add-item-form" class="item-form">
                <div class="form-group">
                    <label for="item-code">Item Code</label>
                    <input type="text" id="item-code" required>
                </div>
                <div class="form-group">
                    <label for="item-name">Item Name</label>
                    <input type="text" id="item-name" required>
                </div>
                <div class="form-group">
                    <label for="item-category">Category</label>
                    <select id="item-category" required>
                        <option value="">Select Category</option>
                        <option value="Electronics">Electronics</option>
                        <option value="Clothing">Clothing</option>
                        <option value="Food">Food</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="item-cost">Cost Price</label>
                    <input type="number" id="item-cost" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="item-price">Selling Price</label>
                    <input type="number" id="item-price" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="item-stock">Stock Quantity</label>
                    <input type="number" id="item-stock" required>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Add Item</button>
                    <button type="button" class="btn btn-secondary" onclick="Utils.closeModal()">Cancel</button>
                </div>
            </form>
        `;

        Utils.openModal('Add New Item', modalContent);

        // Add form submit handler
        const form = document.getElementById('add-item-form');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addItem();
            });
        } else {
            console.error('Add item form not found');
        }
    }

    async addItem() {
        try {
            const code = document.getElementById('item-code').value;
            const name = document.getElementById('item-name').value;
            const category = document.getElementById('item-category').value;
            const costPrice = parseFloat(document.getElementById('item-cost').value);
            const sellingPrice = parseFloat(document.getElementById('item-price').value);
            const stock = parseInt(document.getElementById('item-stock').value);

            // Validate inputs
            if (!code || !name || !category || isNaN(costPrice) || isNaN(sellingPrice) || isNaN(stock)) {
                throw new Error('Please fill in all fields correctly');
            }

            const item = {
                code,
                name,
                category,
                costPrice,
                sellingPrice,
                stock,
                status: 'in-stock',
                createdAt: new Date().toISOString()
            };

            console.log('Adding item:', item);

            if (!window.dbManager) {
                console.error('Database manager not found');
                throw new Error('Database manager not initialized');
            }

            if (!window.dbManager.isDatabaseReady()) {
                console.error('Database not ready');
                throw new Error('Database not ready. Please try again.');
            }

            console.log('Getting inventory store...');
            const store = window.dbManager.getStore('inventory', 'readwrite');
            
            console.log('Adding item to store...');
            const request = store.add(item);

            request.onsuccess = () => {
                console.log('Item added successfully');
                Utils.showToast('Item added successfully', 'success');
                Utils.closeModal();
                this.loadInventory();
            };

            request.onerror = (event) => {
                console.error('Error adding item:', event.target.error);
                if (event.target.error.name === 'ConstraintError') {
                    Utils.showToast('Item code already exists. Please use a different code.', 'error');
                } else {
                    Utils.showToast('Error adding item: ' + event.target.error.message, 'error');
                }
            };

        } catch (error) {
            console.error('Error in addItem:', error);
            Utils.showToast(error.message, 'error');
        }
    }

    async loadInventory() {
        try {
            console.log('loadInventory() called');
            if (!window.dbManager || !window.dbManager.isDatabaseReady()) {
                console.error('Database not initialized');
                return;
            }

            const store = window.dbManager.getStore('inventory', 'readonly');
            const request = store.getAll();

            request.onsuccess = (event) => {
                const items = event.target.result;
                console.log('Loaded items:', items);
                this.renderInventory(items);
            };

            request.onerror = (event) => {
                console.error('Error loading inventory:', event.target.error);
                Utils.showToast('Error loading inventory: ' + event.target.error.message, 'error');
            };

        } catch (error) {
            console.error('Error in loadInventory:', error);
            Utils.showToast('Error loading inventory: ' + error.message, 'error');
        }
    }

    renderInventory(items) {
        console.log('renderInventory() called with items:', items);
        if (!this.inventoryTable) {
            console.error('Inventory table not found');
            return;
        }

        this.inventoryTable.innerHTML = '';
        
        if (!items || items.length === 0) {
            console.log('No items to display');
            this.inventoryTable.innerHTML = `
                <tr>
                    <td colspan="7" class="no-items">No items found</td>
                </tr>
            `;
            return;
        }

        items.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.code || ''}</td>
                <td>${item.name || ''}</td>
                <td>${item.category || ''}</td>
                <td>${Utils.formatCurrency(item.costPrice || 0)}</td>
                <td>${Utils.formatCurrency(item.sellingPrice || 0)}</td>
                <td>${item.stock || 0}</td>
                <td>
                    <button class="btn btn-icon" onclick="inventoryManager.editItem(${item.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-icon" onclick="inventoryManager.deleteItem(${item.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            this.inventoryTable.appendChild(row);
        });
    }

    async filterInventory() {
        console.log('filterInventory() called');
        const searchTerm = this.searchInput ? this.searchInput.value.toLowerCase() : '';
        const categoryFilter = this.categoryFilter ? this.categoryFilter.value : '';
        const statusFilter = this.statusFilter ? this.statusFilter.value : '';

        try {
            if (!window.dbManager || !window.dbManager.isDatabaseReady()) {
                throw new Error('Database not initialized');
            }

            const store = window.dbManager.getStore('inventory', 'readonly');
            const request = store.getAll();

            request.onsuccess = (event) => {
                const items = event.target.result;
                const filteredItems = items.filter(item => {
                    const matchesSearch = !searchTerm || 
                        (item.name && item.name.toLowerCase().includes(searchTerm)) || 
                        (item.code && item.code.toLowerCase().includes(searchTerm));
                    const matchesCategory = !categoryFilter || item.category === categoryFilter;
                    const matchesStatus = !statusFilter || item.status === statusFilter;

                    return matchesSearch && matchesCategory && matchesStatus;
                });

                console.log('Filtered items:', filteredItems);
                this.renderInventory(filteredItems);
            };

            request.onerror = (event) => {
                console.error('Error filtering inventory:', event.target.error);
                Utils.showToast('Error filtering inventory: ' + event.target.error.message, 'error');
            };
        } catch (error) {
            console.error('Error in filterInventory:', error);
            Utils.showToast('Error filtering inventory: ' + error.message, 'error');
        }
    }

    async editItem(id) {
        console.log('editItem() called with id:', id);
        try {
            const store = window.dbManager.getStore('inventory', 'readonly');
            const request = store.get(id);

            request.onsuccess = (event) => {
                const item = event.target.result;
                if (!item) {
                    Utils.showToast('Item not found', 'error');
                    return;
                }

                const modalContent = `
                    <form id="edit-item-form" class="item-form">
                        <div class="form-group">
                            <label for="item-code">Item Code</label>
                            <input type="text" id="item-code" value="${item.code || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="item-name">Item Name</label>
                            <input type="text" id="item-name" value="${item.name || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="item-category">Category</label>
                            <select id="item-category" required>
                                <option value="">Select Category</option>
                                <option value="Electronics" ${item.category === 'Electronics' ? 'selected' : ''}>Electronics</option>
                                <option value="Clothing" ${item.category === 'Clothing' ? 'selected' : ''}>Clothing</option>
                                <option value="Food" ${item.category === 'Food' ? 'selected' : ''}>Food</option>
                                <option value="Other" ${item.category === 'Other' ? 'selected' : ''}>Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="item-cost">Cost Price</label>
                            <input type="number" id="item-cost" step="0.01" value="${item.costPrice || 0}" required>
                        </div>
                        <div class="form-group">
                            <label for="item-price">Selling Price</label>
                            <input type="number" id="item-price" step="0.01" value="${item.sellingPrice || 0}" required>
                        </div>
                        <div class="form-group">
                            <label for="item-stock">Stock Quantity</label>
                            <input type="number" id="item-stock" value="${item.stock || 0}" required>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                            <button type="button" class="btn btn-secondary" onclick="Utils.closeModal()">Cancel</button>
                        </div>
                    </form>
                `;

                Utils.openModal('Edit Item', modalContent);

                // Add form submit handler
                const form = document.getElementById('edit-item-form');
                if (form) {
                    form.addEventListener('submit', async (e) => {
                        e.preventDefault();
                        await this.updateItem(id);
                    });
                }
            };

            request.onerror = (event) => {
                console.error('Error getting item:', event.target.error);
                Utils.showToast('Error getting item details', 'error');
            };
        } catch (error) {
            console.error('Error in editItem:', error);
            Utils.showToast('Error editing item: ' + error.message, 'error');
        }
    }

    async updateItem(id) {
        try {
            const code = document.getElementById('item-code').value;
            const name = document.getElementById('item-name').value;
            const category = document.getElementById('item-category').value;
            const costPrice = parseFloat(document.getElementById('item-cost').value);
            const sellingPrice = parseFloat(document.getElementById('item-price').value);
            const stock = parseInt(document.getElementById('item-stock').value);

            // Validate inputs
            if (!code || !name || !category || isNaN(costPrice) || isNaN(sellingPrice) || isNaN(stock)) {
                throw new Error('Please fill in all fields correctly');
            }

            const item = {
                id,
                code,
                name,
                category,
                costPrice,
                sellingPrice,
                stock,
                status: 'in-stock',
                updatedAt: new Date().toISOString()
            };

            const store = window.dbManager.getStore('inventory', 'readwrite');
            const request = store.put(item);

            request.onsuccess = () => {
                Utils.showToast('Item updated successfully', 'success');
                Utils.closeModal();
                this.loadInventory();
            };

            request.onerror = (event) => {
                console.error('Error updating item:', event.target.error);
                if (event.target.error.name === 'ConstraintError') {
                    Utils.showToast('Item code already exists. Please use a different code.', 'error');
                } else {
                    Utils.showToast('Error updating item: ' + event.target.error.message, 'error');
                }
            };
        } catch (error) {
            console.error('Error in updateItem:', error);
            Utils.showToast(error.message, 'error');
        }
    }

    async deleteItem(id) {
        console.log('deleteItem() called with id:', id);
        try {
            if (confirm('Are you sure you want to delete this item?')) {
                const store = window.dbManager.getStore('inventory', 'readwrite');
                const request = store.delete(id);

                request.onsuccess = () => {
                    Utils.showToast('Item deleted successfully', 'success');
                    this.loadInventory();
                };

                request.onerror = (event) => {
                    console.error('Error deleting item:', event.target.error);
                    Utils.showToast('Error deleting item: ' + event.target.error.message, 'error');
                };
            }
        } catch (error) {
            console.error('Error in deleteItem:', error);
            Utils.showToast('Error deleting item: ' + error.message, 'error');
        }
    }
}

// Make sure InventoryManager is available globally
window.InventoryManager = InventoryManager;

// Initialize inventory manager
console.log('Setting up inventory manager...');
window.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Content Loaded - creating inventory manager');
    window.inventoryManager = new InventoryManager();
});
