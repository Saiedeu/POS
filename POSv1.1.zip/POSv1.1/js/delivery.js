class DeliveryManager {
    constructor() {
        this.items = [];
        this.itemsContainer = document.getElementById('delivery-items');
        this.init();
    }

    async init() {
        // Wait for database to be ready
        if (!window.dbManager || !window.dbManager.db) {
            window.addEventListener('database-ready', () => this.loadInventory());
        } else {
            await this.loadInventory();
        }

        // Initialize event listeners
        document.getElementById('add-item-btn').addEventListener('click', () => this.addItemRow());
        
        // Load existing delivery notes
        this.loadDeliveryNotes();
    }

    async loadInventory() {
        try {
            const store = window.dbManager.getStore('inventory', 'readonly');
            const request = store.getAll();

            request.onsuccess = () => {
                this.items = request.result;
                console.log('Loaded inventory items:', this.items);
            };

            request.onerror = () => {
                console.error('Error loading inventory:', request.error);
                Utils.showToast('Error loading inventory items', 'error');
            };
        } catch (error) {
            console.error('Error accessing inventory store:', error);
            Utils.showToast('Error accessing inventory', 'error');
        }
    }

    addItemRow() {
        const row = document.createElement('div');
        row.className = 'delivery-item';
        row.innerHTML = `
            <div class="item-row">
                <div class="item-select-wrapper">
                    <input type="text" class="item-search" placeholder="Search or enter new item...">
                    <div class="item-dropdown" style="display: none;">
                        <div class="dropdown-content">
                            <!-- Items will be populated here -->
                        </div>
                    </div>
                </div>
                <input type="number" class="item-quantity" min="1" value="1" placeholder="Qty">
                <input type="text" class="item-description" placeholder="Description">
                <button type="button" class="btn btn-icon remove-item">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        const searchInput = row.querySelector('.item-search');
        const dropdown = row.querySelector('.item-dropdown');
        const dropdownContent = row.querySelector('.dropdown-content');

        // Show dropdown on focus
        searchInput.addEventListener('focus', () => {
            this.updateDropdown(dropdownContent, searchInput.value);
            dropdown.style.display = 'block';
        });

        // Handle search input
        searchInput.addEventListener('input', () => {
            this.updateDropdown(dropdownContent, searchInput.value);
        });

        // Hide dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!row.contains(e.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Handle remove button
        row.querySelector('.remove-item').addEventListener('click', () => {
            row.remove();
        });

        this.itemsContainer.appendChild(row);
    }

    updateDropdown(dropdownContent, searchTerm) {
        const term = searchTerm.toLowerCase();
        const matchingItems = this.items.filter(item => 
            item.name.toLowerCase().includes(term)
        );

        let html = '';
        
        // Add "Create New Item" option
        html += `
            <div class="dropdown-item create-new">
                <i class="fas fa-plus"></i> Create "${searchTerm}"
            </div>
        `;

        // Add matching inventory items
        matchingItems.forEach(item => {
            html += `
                <div class="dropdown-item" data-id="${item.id}">
                    <span class="item-name">${item.name}</span>
                </div>
            `;
        });

        dropdownContent.innerHTML = html;

        // Add click handlers
        const row = dropdownContent.closest('.delivery-item');
        const searchInput = row.querySelector('.item-search');
        const dropdown = row.querySelector('.item-dropdown');

        // Handle existing item selection
        dropdownContent.querySelectorAll('.dropdown-item:not(.create-new)').forEach(item => {
            item.addEventListener('click', () => {
                searchInput.value = item.querySelector('.item-name').textContent;
                dropdown.style.display = 'none';
            });
        });

        // Handle new item creation
        dropdownContent.querySelector('.create-new').addEventListener('click', () => {
            searchInput.value = searchTerm;
            dropdown.style.display = 'none';
            
            // Save new item
            this.saveNewInventoryItem(searchTerm, 0).then(newItem => {
                this.items.push(newItem);
                Utils.showToast('New item saved to inventory', 'success');
            }).catch(error => {
                console.error('Error saving new item:', error);
                Utils.showToast('Error saving new item', 'error');
            });
        });
    }

    async saveNewInventoryItem(name, price = 0) {
        try {
            const store = window.dbManager.getStore('inventory', 'readwrite');
            const newItem = {
                id: `INV${Date.now()}`,
                name: name,
                price: price,
                createdAt: new Date().toISOString()
            };

            await store.add(newItem);
            return newItem;
        } catch (error) {
            console.error('Error saving new inventory item:', error);
            throw error;
        }
    }

    async loadDeliveryNotes() {
        try {
            const store = window.dbManager.getStore('deliveries', 'readonly');
            const request = store.getAll();

            request.onsuccess = () => {
                const deliveries = request.result;
                this.renderDeliveryNotes(deliveries);
            };
        } catch (error) {
            console.error('Error loading delivery notes:', error);
            Utils.showToast('Error loading delivery notes', 'error');
        }
    }

    renderDeliveryNotes(deliveries) {
        const container = document.getElementById('delivery-notes-list');
        if (!container) return;

        if (deliveries.length === 0) {
            container.innerHTML = '<div class="no-data">No delivery notes found</div>';
            return;
        }

        container.innerHTML = deliveries.map(delivery => `
            <div class="delivery-note-card">
                <div class="delivery-header">
                    <h3>Delivery #${delivery.id}</h3>
                    <span class="delivery-date">${new Date(delivery.date).toLocaleDateString()}</span>
                </div>
                <div class="delivery-items">
                    ${delivery.items.map(item => `
                        <div class="delivery-item-row">
                            <span class="item-name">${item.name}</span>
                            <span class="item-quantity">x${item.quantity}</span>
                        </div>
                    `).join('')}
                </div>
                <div class="delivery-actions">
                    <button class="btn btn-secondary" onclick="deliveryManager.viewDelivery('${delivery.id}')">
                        <i class="fas fa-eye"></i> View
                    </button>
                    <button class="btn btn-primary" onclick="deliveryManager.printDelivery('${delivery.id}')">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        `).join('');
    }

    async saveDeliveryNote() {
        try {
            const items = Array.from(this.itemsContainer.querySelectorAll('.delivery-item'))
                .map(row => ({
                    name: row.querySelector('.item-search').value,
                    quantity: parseFloat(row.querySelector('.item-quantity').value),
                    description: row.querySelector('.item-description').value
                }));

            const deliveryNote = {
                id: await this.generateDeliveryNumber(),
                date: new Date().toISOString(),
                clientId: document.getElementById('client-select').value,
                clientName: document.getElementById('client-select').options[document.getElementById('client-select').selectedIndex].text,
                items: items,
                status: 'pending'
            };

            const store = window.dbManager.getStore('deliveries', 'readwrite');
            await store.add(deliveryNote);

            Utils.showToast('Delivery note saved successfully', 'success');
            this.clearForm();
            this.loadDeliveryNotes(); // Refresh the list

        } catch (error) {
            console.error('Error saving delivery note:', error);
            Utils.showToast('Error saving delivery note', 'error');
        }
    }

    async generateDeliveryNumber() {
        const year = new Date().getFullYear();
        const store = window.dbManager.getStore('deliveries', 'readonly');
        const request = store.getAll();

        return new Promise((resolve, reject) => {
            request.onsuccess = () => {
                const deliveries = request.result;
                const lastNumber = deliveries
                    .map(d => parseInt(d.id.replace('AMT', '').slice(-2)))
                    .reduce((max, num) => Math.max(max, num), 0);
                const newNumber = (lastNumber + 1).toString().padStart(2, '0');
                resolve(`AMT${year}${newNumber}`);
            };
            request.onerror = () => reject(new Error('Failed to generate delivery number'));
        });
    }

    async printDelivery(id) {
        try {
            const store = window.dbManager.getStore('deliveries', 'readonly');
            const request = store.get(id);

            request.onsuccess = () => {
                const delivery = request.result;
                if (delivery) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <html>
                        <head>
                            <title>Delivery Note #${delivery.id}</title>
                            <style>
                                @media print {
                                    @page { margin: 0.5cm; }
                                }
                                body { 
                                    font-family: Arial, sans-serif; 
                                    padding: 20px;
                                    max-width: 80mm;
                                    margin: 0 auto;
                                }
                                .header { 
                                    text-align: center; 
                                    margin-bottom: 20px;
                                    border-bottom: 1px solid #000;
                                    padding-bottom: 10px;
                                }
                                .company-name {
                                    font-size: 1.2em;
                                    font-weight: bold;
                                    margin: 5px 0;
                                }
                                .company-details {
                                    font-size: 0.9em;
                                    margin: 3px 0;
                                }
                                .delivery-details {
                                    margin: 15px 0;
                                    font-size: 0.9em;
                                }
                                .items { 
                                    margin: 20px 0;
                                    border-top: 1px solid #ccc;
                                    border-bottom: 1px solid #ccc;
                                }
                                .item { 
                                    padding: 8px 0;
                                    border-bottom: 1px dashed #eee;
                                }
                                .item:last-child {
                                    border-bottom: none;
                                }
                                .signature-line {
                                    margin-top: 40px;
                                    border-top: 1px solid #000;
                                    padding-top: 10px;
                                    text-align: center;
                                }
                                .footer {
                                    margin-top: 30px;
                                    text-align: center;
                                    font-size: 0.8em;
                                }
                            </style>
                        </head>
                        <body>
                            <div class="header">
                                <div class="company-name">Al Misbah Trading</div>
                                <div class="company-details">P.O. Box 3634, Doha - Qatar</div>
                                <div class="company-details">Tel: +974 4432 7432, Fax: +974 4441 3466</div>
                                <div class="company-details">Email: almisbah@qatar.net.qa</div>
                            </div>
                            <div class="delivery-details">
                                <h2>Delivery Note</h2>
                                <div>Note #: ${delivery.id}</div>
                                <div>Date: ${new Date(delivery.date).toLocaleDateString()}</div>
                                <div>Client: ${delivery.clientName}</div>
                            </div>
                            <div class="items">
                                <h3>Items:</h3>
                                ${delivery.items.map(item => `
                                    <div class="item">
                                        <div><strong>${item.name}</strong></div>
                                        <div>Quantity: ${item.quantity}</div>
                                        ${item.description ? `<div>Description: ${item.description}</div>` : ''}
                                    </div>
                                `).join('')}
                            </div>
                            <div class="signature-line">
                                <p>Received By: _________________________</p>
                                <p>Date: _________________________</p>
                                <p>Signature: _________________________</p>
                            </div>
                            <div class="footer">
                                <p>Thank you for your business!</p>
                            </div>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                    printWindow.print();
                }
            };
        } catch (error) {
            console.error('Error printing delivery:', error);
            Utils.showToast('Error printing delivery note', 'error');
        }
    }

    clearForm() {
        this.itemsContainer.innerHTML = '';
        document.getElementById('client-select').value = '';
    }

    async viewDelivery(id) {
        try {
            const store = window.dbManager.getStore('deliveries', 'readonly');
            const request = store.get(id);

            request.onsuccess = () => {
                const delivery = request.result;
                if (delivery) {
                    this.showDeliveryModal(delivery);
                } else {
                    Utils.showToast('Delivery note not found', 'error');
                }
            };
        } catch (error) {
            console.error('Error viewing delivery:', error);
            Utils.showToast('Error viewing delivery note', 'error');
        }
    }

    showDeliveryModal(delivery) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Delivery Note #${delivery.id}</h2>
                    <button class="close-btn">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="delivery-info">
                        <p><strong>Date:</strong> ${new Date(delivery.date).toLocaleDateString()}</p>
                        <p><strong>Status:</strong> ${delivery.status}</p>
                    </div>
                    <div class="delivery-items">
                        <h3>Items</h3>
                        ${delivery.items.map(item => `
                            <div class="delivery-item-row">
                                <span class="item-name">${item.name}</span>
                                <span class="item-quantity">x${item.quantity}</span>
                                ${item.description ? `<span class="item-description">${item.description}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" onclick="this.closest('.modal').remove()">Close</button>
                    <button class="btn btn-primary" onclick="deliveryManager.printDelivery('${delivery.id}')">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        modal.querySelector('.close-btn').onclick = () => modal.remove();
    }
}

// Initialize delivery manager
window.addEventListener('DOMContentLoaded', () => {
    window.deliveryManager = new DeliveryManager();
});