class QuotationManager {
    constructor() {
        this.items = [];
        this.cart = [];
        this.currentQuotationNumber = null;
        
        // Initialize UI elements
        this.initializeUIElements();
        this.init();
    }

    initializeUIElements() {
        // Search elements
        this.itemSearchInput = document.getElementById('quotation-item-search');
        this.itemsContainer = document.getElementById('quotation-items-container');
        
        // Cart elements
        this.cartItemsContainer = document.getElementById('quotation-cart-items');
        this.subtotalElement = document.getElementById('quotation-subtotal');
        this.discountAmountInput = document.getElementById('quotation-discount-amount');
        this.discountTypeSelect = document.getElementById('quotation-discount-type');
        this.discountValueElement = document.getElementById('quotation-discount-value');
        this.totalAmountElement = document.getElementById('quotation-total-amount');
        
        // Customer info elements
        this.quotationNumberInput = document.getElementById('quotation-number');
        this.quotationDateInput = document.getElementById('quotation-date');
        this.customerNameInput = document.getElementById('quotation-customer-name');
        
        // Action buttons
        this.clearCartBtn = document.getElementById('quotation-clear-cart-btn');
        this.saveQuotationBtn = document.getElementById('save-quotation-btn');
        this.printQuotationBtn = document.getElementById('print-quotation-btn');
        
        // Quotations list
        this.quotationsListBody = document.getElementById('quotations-list-body');
        this.addQuotationBtn = document.getElementById('add-quotation-btn');
    }

    async init() {
        // Wait for database to be ready
        if (!window.dbManager || !window.dbManager.db) {
            window.addEventListener('database-ready', () => this.loadInventory());
        } else {
            await this.loadInventory();
        }

        // Set current date
        this.quotationDateInput.valueAsDate = new Date();

        // Initialize event listeners
        this.initializeEventListeners();
        
        // Load existing quotations
        await this.loadQuotations();
    }

    initializeEventListeners() {
        // Search functionality
        this.itemSearchInput.addEventListener('input', () => this.handleItemSearch());
        
        // Discount changes
        this.discountAmountInput.addEventListener('input', () => this.updateTotals());
        this.discountTypeSelect.addEventListener('change', () => this.updateTotals());
        
        // Action buttons
        this.clearCartBtn.addEventListener('click', () => this.clearCart());
        this.saveQuotationBtn.addEventListener('click', () => this.saveQuotation());
        this.printQuotationBtn.addEventListener('click', () => this.printQuotation());
        this.addQuotationBtn.addEventListener('click', () => this.startNewQuotation());
    }

    async loadInventory() {
        try {
            const store = window.dbManager.getStore('inventory', 'readonly');
            const request = store.getAll();

            request.onsuccess = () => {
                this.items = request.result;
                this.renderItems(this.items);
            };

            request.onerror = () => {
                console.error('Error loading inventory:', request.error);
                Utils.showToast('Error loading inventory items', 'error');
            };
        } catch (error) {
            console.error('Error accessing inventory store:', error);
            Utils.showToast('Error accessing inventory', 'error');
        }
    }

    handleItemSearch() {
        const searchTerm = this.itemSearchInput.value.toLowerCase();
        const filteredItems = this.items.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.code.toLowerCase().includes(searchTerm)
        );
        this.renderItems(filteredItems);
    }

    renderItems(items) {
        this.itemsContainer.innerHTML = '';
        items.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'quotation-item';
            itemElement.innerHTML = `
                <div class="item-details">
                    <div>
                        <div class="item-name">${item.name}</div>
                        <div class="item-code">${item.code}</div>
                    </div>
                    <div class="item-price">QAR ${item.sellingPrice.toFixed(2)}</div>
                </div>
            `;
            itemElement.addEventListener('click', () => this.addToCart(item));
            this.itemsContainer.appendChild(itemElement);
        });
    }

    addToCart(item) {
        const existingItem = this.cart.find(cartItem => cartItem.code === item.code);
        
        if (existingItem) {
            existingItem.quantity++;
            existingItem.total = existingItem.quantity * existingItem.price;
        } else {
            this.cart.push({
                code: item.code,
                name: item.name,
                quantity: 1,
                price: item.sellingPrice,
                total: item.sellingPrice
            });
        }
        
        this.renderCart();
        this.updateTotals();
    }

    renderCart() {
        this.cartItemsContainer.innerHTML = '';
        this.cart.forEach((item, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.code}</td>
                <td>${item.name}</td>
                <td>
                    <input type="number" value="${item.quantity}" min="1" 
                           onchange="quotationManager.updateItemQuantity(${index}, this.value)">
                </td>
                <td>${item.unit || 'PCS'}</td>
                <td>QAR ${item.price.toFixed(2)}</td>
                <td>QAR ${item.total.toFixed(2)}</td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="quotationManager.removeFromCart(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            this.cartItemsContainer.appendChild(row);
        });
    }

    updateItemQuantity(index, quantity) {
        quantity = parseInt(quantity);
        if (quantity < 1) quantity = 1;
        
        this.cart[index].quantity = quantity;
        this.cart[index].total = quantity * this.cart[index].price;
        
        this.renderCart();
        this.updateTotals();
    }

    removeFromCart(index) {
        this.cart.splice(index, 1);
        this.renderCart();
        this.updateTotals();
    }

    updateTotals() {
        const subtotal = this.cart.reduce((sum, item) => sum + item.total, 0);
        this.subtotalElement.textContent = subtotal.toFixed(2);

        const discountAmount = parseFloat(this.discountAmountInput.value) || 0;
        const discountType = this.discountTypeSelect.value;
        let discountValue = 0;

        if (discountType === 'percentage') {
            discountValue = subtotal * (discountAmount / 100);
        } else {
            discountValue = discountAmount;
        }

        this.discountValueElement.textContent = discountValue.toFixed(2);
        
        const total = subtotal - discountValue;
        this.totalAmountElement.textContent = total.toFixed(2);
    }

    clearCart() {
        this.cart = [];
        this.renderCart();
        this.updateTotals();
    }

    async saveQuotation() {
        if (this.cart.length === 0) {
            Utils.showToast('Please add items to the quotation', 'error');
            return;
        }

        if (!this.customerNameInput.value) {
            Utils.showToast('Please enter customer name', 'error');
            return;
        }

        const quotation = {
            number: this.quotationNumberInput.value || await this.generateQuotationNumber(),
            date: this.quotationDateInput.value,
            customerName: this.customerNameInput.value,
            items: [...this.cart],
            subtotal: parseFloat(this.subtotalElement.textContent),
            discountType: this.discountTypeSelect.value,
            discountAmount: parseFloat(this.discountAmountInput.value) || 0,
            discountValue: parseFloat(this.discountValueElement.textContent),
            total: parseFloat(this.totalAmountElement.textContent),
            status: 'pending',
            createdAt: new Date().toISOString()
        };

        try {
            const store = window.dbManager.getStore('quotations', 'readwrite');
            const request = store.add(quotation);

            request.onsuccess = () => {
                Utils.showToast('Quotation saved successfully', 'success');
                this.loadQuotations();
                this.startNewQuotation();
            };

            request.onerror = () => {
                console.error('Error saving quotation:', request.error);
                Utils.showToast('Error saving quotation', 'error');
            };
        } catch (error) {
            console.error('Error accessing quotations store:', error);
            Utils.showToast('Error accessing database', 'error');
        }
    }

    async generateQuotationNumber() {
        const date = new Date();
        const year = date.getFullYear().toString().substr(-2);
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        
        try {
            const store = window.dbManager.getStore('quotations', 'readonly');
            const request = store.count();
            
            return new Promise((resolve, reject) => {
                request.onsuccess = () => {
                    const count = request.result + 1;
                    resolve(`Q${year}${month}${count.toString().padStart(4, '0')}`);
                };
                
                request.onerror = () => {
                    console.error('Error getting quotation count:', request.error);
                    reject(request.error);
                };
            });
        } catch (error) {
            console.error('Error accessing quotations store:', error);
            return `Q${year}${month}0001`;
        }
    }

    async loadQuotations() {
        try {
            const store = window.dbManager.getStore('quotations', 'readonly');
            const request = store.getAll();

            request.onsuccess = () => {
                const quotations = request.result;
                this.renderQuotations(quotations);
            };

            request.onerror = () => {
                console.error('Error loading quotations:', request.error);
                Utils.showToast('Error loading quotations', 'error');
            };
        } catch (error) {
            console.error('Error accessing quotations store:', error);
            Utils.showToast('Error accessing database', 'error');
        }
    }

    renderQuotations(quotations) {
        this.quotationsListBody.innerHTML = '';
        quotations.forEach(quotation => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${quotation.number}</td>
                <td>${new Date(quotation.date).toLocaleDateString()}</td>
                <td>${quotation.customerName}</td>
                <td>${quotation.items.length}</td>
                <td>QAR ${quotation.total.toFixed(2)}</td>
                <td><span class="status-badge status-${quotation.status}">${quotation.status}</span></td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="quotationManager.viewQuotation('${quotation.number}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-success btn-sm" onclick="quotationManager.printQuotation('${quotation.number}')">
                        <i class="fas fa-print"></i>
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="quotationManager.deleteQuotation('${quotation.number}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            this.quotationsListBody.appendChild(row);
        });
    }

    startNewQuotation() {
        this.currentQuotationNumber = null;
        this.quotationNumberInput.value = '';
        this.quotationDateInput.valueAsDate = new Date();
        this.customerNameInput.value = '';
        this.clearCart();
        this.discountAmountInput.value = '';
        this.discountTypeSelect.value = 'fixed';
    }

    async viewQuotation(number) {
        try {
            const store = window.dbManager.getStore('quotations', 'readonly');
            const request = store.get(number);

            request.onsuccess = () => {
                const quotation = request.result;
                if (quotation) {
                    this.loadQuotationToForm(quotation);
                } else {
                    Utils.showToast('Quotation not found', 'error');
                }
            };

            request.onerror = () => {
                console.error('Error loading quotation:', request.error);
                Utils.showToast('Error loading quotation', 'error');
            };
        } catch (error) {
            console.error('Error accessing quotations store:', error);
            Utils.showToast('Error accessing database', 'error');
        }
    }

    loadQuotationToForm(quotation) {
        this.currentQuotationNumber = quotation.number;
        this.quotationNumberInput.value = quotation.number;
        this.quotationDateInput.value = quotation.date;
        this.customerNameInput.value = quotation.customerName;
        
        this.cart = [...quotation.items];
        this.renderCart();
        
        this.discountTypeSelect.value = quotation.discountType;
        this.discountAmountInput.value = quotation.discountAmount;
        
        this.updateTotals();
    }

    async deleteQuotation(number) {
        if (!confirm('Are you sure you want to delete this quotation?')) {
            return;
        }

        try {
            const store = window.dbManager.getStore('quotations', 'readwrite');
            const request = store.delete(number);

            request.onsuccess = () => {
                Utils.showToast('Quotation deleted successfully', 'success');
                this.loadQuotations();
            };

            request.onerror = () => {
                console.error('Error deleting quotation:', request.error);
                Utils.showToast('Error deleting quotation', 'error');
            };
        } catch (error) {
            console.error('Error accessing quotations store:', error);
            Utils.showToast('Error accessing database', 'error');
        }
    }

    async printQuotation(number) {
        let quotation;
        
        if (number) {
            try {
                const store = window.dbManager.getStore('quotations', 'readonly');
                const request = store.get(number);
                
                quotation = await new Promise((resolve, reject) => {
                    request.onsuccess = () => resolve(request.result);
                    request.onerror = () => reject(request.error);
                });
            } catch (error) {
                console.error('Error loading quotation for printing:', error);
                Utils.showToast('Error loading quotation', 'error');
                return;
            }
        } else {
            if (this.cart.length === 0) {
                Utils.showToast('Please add items to print quotation', 'error');
                return;
            }
            
            quotation = {
                number: this.quotationNumberInput.value || 'DRAFT',
                date: this.quotationDateInput.value,
                customerName: this.customerNameInput.value || 'Customer',
                items: [...this.cart],
                subtotal: parseFloat(this.subtotalElement.textContent),
                discountType: this.discountTypeSelect.value,
                discountAmount: parseFloat(this.discountAmountInput.value) || 0,
                discountValue: parseFloat(this.discountValueElement.textContent),
                total: parseFloat(this.totalAmountElement.textContent)
            };
        }

        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Quotation ${quotation.number}</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .header { text-align: center; margin-bottom: 30px; }
                    .info { margin-bottom: 20px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    .totals { text-align: right; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>Quotation</h1>
                    <h2>${quotation.number}</h2>
                </div>
                
                <div class="info">
                    <p><strong>Date:</strong> ${new Date(quotation.date).toLocaleDateString()}</p>
                    <p><strong>Customer:</strong> ${quotation.customerName}</p>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${quotation.items.map(item => `
                            <tr>
                                <td>${item.name}</td>
                                <td>${item.quantity}</td>
                                <td>QAR ${item.price.toFixed(2)}</td>
                                <td>QAR ${item.total.toFixed(2)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>

                <div class="totals">
                    <p><strong>Subtotal:</strong> QAR ${quotation.subtotal.toFixed(2)}</p>
                    <p><strong>Discount:</strong> QAR ${quotation.discountValue.toFixed(2)}</p>
                    <p><strong>Total:</strong> QAR ${quotation.total.toFixed(2)}</p>
                </div>
            </body>
            </html>
        `);
        
        printWindow.document.close();
        printWindow.print();
    }
}

// Initialize quotation manager
window.addEventListener('DOMContentLoaded', () => {
    window.quotationManager = new QuotationManager();
});