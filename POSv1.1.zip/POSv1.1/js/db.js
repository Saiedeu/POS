// Database initialization and management
class DatabaseManager {
    constructor() {
        this.dbName = 'pos_system';
        this.dbVersion = 3; // Increment version to trigger schema update
        this.db = null;
        this.init();
    }

    async init() {
        try {
            console.log('Initializing database...');
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onerror = (event) => {
                console.error('Database error:', event.target.error);
                if (window.Utils) {
                    Utils.showToast('Database error: ' + event.target.error.message, 'error');
                }
            };

            request.onsuccess = (event) => {
                console.log('Database opened successfully');
                this.db = event.target.result;
                window.db = this.db;  // Make db available globally
                window.dispatchEvent(new CustomEvent('database-ready', { detail: { db: this.db } }));
            };

            request.onupgradeneeded = (event) => {
                console.log('Database upgrade needed');
                const db = event.target.result;

                // Delete existing stores if they exist
                if (db.objectStoreNames.contains('inventory')) {
                    db.deleteObjectStore('inventory');
                }
                if (db.objectStoreNames.contains('clients')) {
                    db.deleteObjectStore('clients');
                }
                if (db.objectStoreNames.contains('quotations')) {
                    db.deleteObjectStore('quotations');
                }
                if (db.objectStoreNames.contains('deliveries')) {
                    db.deleteObjectStore('deliveries');
                }
                if (db.objectStoreNames.contains('sales')) {
                    db.deleteObjectStore('sales');
                }

                // Create inventory store
                const inventoryStore = db.createObjectStore('inventory', { keyPath: 'id', autoIncrement: true });
                inventoryStore.createIndex('code', 'code', { unique: true });
                inventoryStore.createIndex('name', 'name', { unique: false });
                inventoryStore.createIndex('category', 'category', { unique: false });
                inventoryStore.createIndex('unit', 'unit', { unique: false });
                console.log('Created inventory store');

                // Create clients store
                const clientsStore = db.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
                clientsStore.createIndex('email', 'email', { unique: false }); // Changed to false to prevent blocking
                clientsStore.createIndex('name', 'name', { unique: false });
                clientsStore.createIndex('phone', 'phone', { unique: false });
                clientsStore.createIndex('category', 'category', { unique: false });
                clientsStore.createIndex('status', 'status', { unique: false });
                console.log('Created clients store');

                // Create quotations store
                const quotationsStore = db.createObjectStore('quotations', { keyPath: 'id', autoIncrement: true });
                quotationsStore.createIndex('number', 'number', { unique: true });
                quotationsStore.createIndex('clientId', 'clientId', { unique: false });
                quotationsStore.createIndex('date', 'date', { unique: false });
                quotationsStore.createIndex('status', 'status', { unique: false });
                quotationsStore.createIndex('items', 'items', { unique: false });
                quotationsStore.createIndex('total', 'total', { unique: false });
                console.log('Created quotations store');

                // Create deliveries store
                const deliveriesStore = db.createObjectStore('deliveries', { keyPath: 'id', autoIncrement: true });
                deliveriesStore.createIndex('number', 'number', { unique: true });
                deliveriesStore.createIndex('quotationId', 'quotationId', { unique: false });
                deliveriesStore.createIndex('clientId', 'clientId', { unique: false });
                deliveriesStore.createIndex('date', 'date', { unique: false });
                deliveriesStore.createIndex('status', 'status', { unique: false });
                deliveriesStore.createIndex('items', 'items', { unique: false });
                console.log('Created deliveries store');

                // Create sales store
                const salesStore = db.createObjectStore('sales', { keyPath: 'id', autoIncrement: true });
                salesStore.createIndex('date', 'date', { unique: false });
                salesStore.createIndex('total', 'total', { unique: false });
                salesStore.createIndex('clientId', 'clientId', { unique: false });
                salesStore.createIndex('items', 'items', { unique: false });
                salesStore.createIndex('paymentMethod', 'paymentMethod', { unique: false });
                console.log('Created sales store');
            };
        } catch (error) {
            console.error('Error initializing database:', error);
            if (window.Utils) {
                Utils.showToast('Error initializing database: ' + error.message, 'error');
            }
        }
    }

    isDatabaseReady() {
        return this.db !== null;
    }

    getStore(storeName, mode = 'readonly') {
        if (!this.isDatabaseReady()) {
            throw new Error('Database not initialized');
        }
        try {
            const transaction = this.db.transaction(storeName, mode);
            return transaction.objectStore(storeName);
        } catch (error) {
            console.error(`Error getting store ${storeName}:`, error);
            throw error;
        }
    }

    async clearAllStores() {
        if (!this.isDatabaseReady()) {
            throw new Error('Database not initialized');
        }

        const stores = ['inventory', 'clients', 'quotations', 'deliveries', 'sales'];
        for (const storeName of stores) {
            try {
                const store = this.getStore(storeName, 'readwrite');
                await new Promise((resolve, reject) => {
                    const request = store.clear();
                    request.onsuccess = () => resolve();
                    request.onerror = () => reject(request.error);
                });
            } catch (error) {
                console.error(`Error clearing store ${storeName}:`, error);
            }
        }
    }
}

// Initialize database manager
console.log('Creating database manager...');
window.dbManager = new DatabaseManager();

// Export database manager
window.DatabaseManager = DatabaseManager;
