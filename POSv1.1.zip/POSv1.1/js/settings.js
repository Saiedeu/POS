class SettingsManager {
    constructor() {
        this.bindElements();
        this.bindEvents();
        this.loadSettings();
    }

    bindElements() {
        this.businessInfoForm = document.getElementById('business-info-form');
    }

    bindEvents() {
        if (this.businessInfoForm) {
            this.businessInfoForm.addEventListener('submit', (e) => this.handleBusinessInfoSubmit(e));
        }
    }

    async loadSettings() {
        try {
            const transaction = db.transaction(['settings'], 'readonly');
            const store = transaction.objectStore('settings');
            const request = store.get('business_info');

            request.onsuccess = () => {
                const businessInfo = request.result;
                if (businessInfo) {
                    this.populateBusinessInfo(businessInfo);
                }
            };
        } catch (error) {
            console.error('Error loading settings:', error);
            Utils.showToast('Error loading settings', 'error');
        }
    }

    populateBusinessInfo(info) {
        if (!this.businessInfoForm) return;

        const fields = this.businessInfoForm.elements;
        for (let field of fields) {
            if (field.name && info[field.name]) {
                field.value = info[field.name];
            }
        }
    }

    async handleBusinessInfoSubmit(e) {
        e.preventDefault();

        const formData = new FormData(this.businessInfoForm);
        const businessInfo = {
            id: 'business_info',
            name: formData.get('business-name'),
            address: formData.get('business-address'),
            phone: formData.get('business-phone'),
            email: formData.get('business-email'),
            tax: formData.get('business-tax'),
            currency: formData.get('business-currency'),
            updatedAt: new Date().toISOString()
        };

        try {
            const transaction = db.transaction(['settings'], 'readwrite');
            const store = transaction.objectStore('settings');
            const request = store.put(businessInfo);

            request.onsuccess = () => {
                Utils.showToast('Business information updated successfully', 'success');
            };

            request.onerror = () => {
                throw new Error('Failed to update business information');
            };
        } catch (error) {
            console.error('Error saving business info:', error);
            Utils.showToast('Error saving business information', 'error');
        }
    }
}
