// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    try {
        // First initialize the UI components
        setupTabNavigation();
        setupEventListeners();
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Initialize managers after database is ready
        window.addEventListener('database-ready', () => {
            console.log('Database ready, initializing managers...');
            
            // Initialize managers one by one with error handling
            try {
                if (typeof InventoryManager === 'undefined') {
                    console.error('InventoryManager not loaded');
                    return;
                }
                window.inventoryManager = new InventoryManager();
                console.log('InventoryManager initialized');

                if (typeof QuotationManager === 'undefined') {
                    console.error('QuotationManager not loaded');
                    return;
                }
                window.quotationManager = new QuotationManager();
                console.log('QuotationManager initialized');

                if (typeof ClientManager === 'undefined') {
                    console.error('ClientManager not loaded');
                    return;
                }
                window.clientsManager = new ClientManager();
                console.log('ClientManager initialized');

                if (typeof DeliveryManager === 'undefined') {
                    console.error('DeliveryManager not loaded');
                    return;
                }
                window.deliveryManager = new DeliveryManager();
                console.log('DeliveryManager initialized');

                Utils.showToast('System initialized successfully', 'success');
            } catch (error) {
                console.error('Error initializing managers:', error);
                Utils.showToast('Error initializing managers: ' + error.message, 'error');
            }
        });
    } catch (error) {
        console.error('Error initializing system:', error);
        Utils.showToast('Error initializing system: ' + error.message, 'error');
    }
});

// Main initialization function
function initializeApp() {
    setupTabNavigation();
    setupEventListeners();
}

// Update date and time in the header
function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const datetimeElement = document.getElementById('datetime');
    if (datetimeElement) {
        datetimeElement.textContent = now.toLocaleDateString('en-US', options);
    }
}

// Setup tab navigation
function setupTabNavigation() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabName = button.getAttribute('data-tab');
            
            // Update active states
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            button.classList.add('active');
            const tabContent = document.getElementById(tabName);
            if (tabContent) {
                tabContent.classList.add('active');
                // Dispatch tab changed event
                window.dispatchEvent(new CustomEvent('tab-changed', { 
                    detail: { tab: tabName }
                }));
            }
        });
    });

    console.log('Tab navigation setup complete');
}

// Setup global event listeners
function setupEventListeners() {
    // Modal events
    const modalContainer = document.querySelector('.modal-container');
    const closeModalBtn = document.querySelector('.close-modal');

    if (modalContainer) {
        modalContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-container')) {
                Utils.closeModal();
            }
        });
    }

    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', Utils.closeModal);
    }

    // Tab keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key >= '1' && e.key <= '7') {
            e.preventDefault();
            const index = parseInt(e.key) - 1;
            const tabButtons = document.querySelectorAll('.tab-button');
            if (tabButtons[index]) {
                tabButtons[index].click();
            }
        }
    });

    console.log('Event listeners setup complete');
}
