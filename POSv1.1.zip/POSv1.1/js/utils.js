// Utility functions for the POS system
const Utils = {
    // Modal handling
    openModal: function(title, content) {
        console.log('Opening modal with title:', title);
        const modalHtml = `
            <div class="modal-overlay">
                <div class="modal">
                    <div class="modal-header">
                        <h3>${title}</h3>
                        <button class="close-btn" onclick="Utils.closeModal()">&times;</button>
                    </div>
                    <div class="modal-content">
                        ${content}
                    </div>
                </div>
            </div>
        `;

        // Remove any existing modal
        this.closeModal();

        // Add new modal
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    },

    closeModal: function() {
        console.log('Closing modal');
        const modal = document.querySelector('.modal-overlay');
        if (modal) {
            modal.remove();
        }
    },

    // Toast notifications
    showToast: function(message, type = 'info') {
        console.log('Showing toast:', message, type);
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas ${this.getToastIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `;

        const container = document.querySelector('.toast-container') || this.createToastContainer();
        container.appendChild(toast);

        // Auto remove after 3 seconds
        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },

    createToastContainer: function() {
        const container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
        return container;
    },

    getToastIcon: function(type) {
        switch (type) {
            case 'success': return 'fa-check-circle';
            case 'error': return 'fa-exclamation-circle';
            case 'warning': return 'fa-exclamation-triangle';
            default: return 'fa-info-circle';
        }
    },

    // Currency formatting
    formatCurrency: function(amount) {
        return `QAR ${new Intl.NumberFormat('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(amount)}`;
    },

    // Date formatting
    formatDate: function(date) {
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(date));
    },

    // Input validation
    validateInput: function(input, type) {
        switch (type) {
            case 'number':
                return !isNaN(parseFloat(input)) && isFinite(input);
            case 'email':
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input);
            case 'phone':
                return /^\+?[\d\s-]{10,}$/.test(input);
            default:
                return true;
        }
    },

    // Debug logging
    log: function(message, type = 'info') {
        const timestamp = new Date().toISOString();
        console.log(`[${timestamp}] [${type.toUpperCase()}] ${message}`);
    },

    // Error handling
    handleError: function(error, context = '') {
        console.error(`Error in ${context}:`, error);
        this.showToast(error.message || 'An error occurred', 'error');
    }
};

// Make Utils globally available
window.Utils = Utils;
