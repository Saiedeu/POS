// Tab management functionality
class TabManager {
    constructor() {
        console.log('Initializing TabManager...');
        this.init();
    }

    init() {
        console.log('TabManager.init() called');
        this.bindElements();
        this.bindEvents();
    }

    bindElements() {
        console.log('TabManager.bindElements() called');
        this.tabButtons = document.querySelectorAll('.tab-button');
        this.tabContents = document.querySelectorAll('.tab-content');
        
        console.log('Found elements:', {
            tabButtons: this.tabButtons.length,
            tabContents: this.tabContents.length
        });
    }

    bindEvents() {
        console.log('TabManager.bindEvents() called');
        this.tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                console.log('Tab button clicked:', button.getAttribute('data-tab'));
                this.switchTab(button);
            });
        });
    }

    switchTab(selectedButton) {
        console.log('switchTab() called with button:', selectedButton.getAttribute('data-tab'));
        
        // Remove active class from all buttons and contents
        this.tabButtons.forEach(button => button.classList.remove('active'));
        this.tabContents.forEach(content => content.classList.remove('active'));

        // Add active class to selected button and corresponding content
        selectedButton.classList.add('active');
        const tabId = selectedButton.getAttribute('data-tab');
        const selectedContent = document.getElementById(tabId);
        
        console.log('Switching to tab:', {
            tabId: tabId,
            contentFound: !!selectedContent
        });

        if (selectedContent) {
            selectedContent.classList.add('active');
            // Dispatch event for tab change
            const event = new CustomEvent('tab-changed', { 
                detail: { 
                    tab: tabId,
                    button: selectedButton,
                    content: selectedContent
                }
            });
            console.log('Dispatching tab-changed event:', event);
            window.dispatchEvent(event);
        } else {
            console.error('Tab content not found for tab:', tabId);
        }
    }
}

// Initialize tab manager
console.log('Setting up tab manager...');
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Content Loaded - creating tab manager');
    window.tabManager = new TabManager();

    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    function switchTab(tabId) {
        // Hide all tabs
        tabContents.forEach(content => {
            content.classList.remove('active');
        });
        tabButtons.forEach(btn => {
            btn.classList.remove('active');
        });

        // Show selected tab
        const selectedTab = document.querySelector(`#${tabId}`);
        const selectedButton = document.querySelector(`[data-tab="${tabId}"]`);
        
        if (selectedTab && selectedButton) {
            selectedTab.classList.add('active');
            selectedButton.classList.add('active');
        }
    }

    // Add click handlers to tab buttons
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabId = button.getAttribute('data-tab');
            switchTab(tabId);
        });
    });
});
