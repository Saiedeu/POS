class POSManager {
    constructor() {
        this.initializeElements();
        this.items = [];
        this.init();
        // Initialize beep sound
        this.beepSound = new Audio('assets/sounds/Barcode Scanner Beep.mp3');
    }

    numberToWords(num) {
        const ones = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE'];
        const tens = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];
        const teens = ['TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];

        if (num === 0) return 'ZERO';

        function convertLessThanThousand(n) {
            if (n === 0) return '';
            
            if (n < 10) return ones[n];
            
            if (n < 20) return teens[n - 10];
            
            if (n < 100) {
                return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
            }
            
            return ones[Math.floor(n / 100)] + ' HUNDRED' + (n % 100 ? ' AND ' + convertLessThanThousand(n % 100) : '');
        }

        let words = '';
        const billions = Math.floor(num / 1000000000);
        const millions = Math.floor((num % 1000000000) / 1000000);
        const thousands = Math.floor((num % 1000000) / 1000);
        const remainder = num % 1000;

        if (billions) words += convertLessThanThousand(billions) + ' BILLION ';
        if (millions) words += convertLessThanThousand(millions) + ' MILLION ';
        if (thousands) words += convertLessThanThousand(thousands) + ' THOUSAND ';
        if (remainder) words += convertLessThanThousand(remainder);

        return words.trim();
    }

    formatCurrency(amount) {
        return amount.toFixed(2);
    }

    initializeElements() {
        this.itemSearch = document.getElementById('item-search');
        this.searchBtn = document.getElementById('search-btn');
        this.quickSaleBtn = document.getElementById('quick-sale-btn');
        this.itemsContainer = document.getElementById('cart-items');
        this.totalAmount = document.getElementById('total-amount');
        this.subtotalElement = document.getElementById('subtotal');
        this.discountInput = document.getElementById('discount-amount');
        this.discountType = document.getElementById('discount-type');
        this.discountValue = document.getElementById('discount-value');
        this.clearCartBtn = document.getElementById('clear-cart-btn');
        this.checkoutBtn = document.getElementById('checkout-btn');
        this.posItems = document.getElementById('pos-items');
        this.customerNameInput = document.getElementById('customer-name');
        this.billDateInput = document.getElementById('bill-date');
        this.addItemBtn = document.getElementById('add-item-btn');

        // Set default date to today
        const today = new Date().toISOString().split('T')[0];
        if (this.billDateInput) {
            this.billDateInput.value = today;
        }

        // Add event listener for add item button
        if (this.addItemBtn) {
            this.addItemBtn.addEventListener('click', () => this.showAddItemModal());
        }

        // Initialize payment method
        this.paymentMethodSelect = document.getElementById('payment-method');
        if (this.paymentMethodSelect) {
            this.paymentMethodSelect.addEventListener('change', () => {
                this.selectedPaymentMethod = this.paymentMethodSelect.value;
            });
            // Set initial payment method
            this.selectedPaymentMethod = this.paymentMethodSelect.value;
        } else {
            this.selectedPaymentMethod = 'cash'; // default if select not found
        }

        // Add event listeners for discount
        if (this.discountInput && this.discountType) {
            this.discountInput.addEventListener('input', () => this.calculateTotal());
            this.discountType.addEventListener('change', () => this.calculateTotal());
        }

        // Add event listener for checkout button
        if (this.checkoutBtn) {
            this.checkoutBtn.addEventListener('click', () => this.processSale());
        }
    }

    async init() {
        try {
            // Wait for database to be ready
            if (!window.dbManager || !window.dbManager.db) {
                window.addEventListener('database-ready', () => this.loadInventory());
            } else {
                await this.loadInventory();
            }

            // Initialize event listeners
            this.itemSearch.addEventListener('input', () => this.handleSearch());
            this.searchBtn.addEventListener('click', () => this.handleSearch());
            this.quickSaleBtn.addEventListener('click', () => this.showQuickSaleModal());
            this.clearCartBtn.addEventListener('click', () => this.clearCart());
        } catch (error) {
            console.error('Error initializing POS:', error);
            Utils.showToast('Error initializing POS system', 'error');
        }
    }

    // Load inventory items from the database
    async loadInventory() {
        try {
            const store = window.dbManager.getStore('inventory', 'readonly');
            const request = store.getAll();

            request.onsuccess = () => {
                this.items = request.result;
                console.log('Loaded inventory items:', this.items);

                // Update POS items display
                this.displaySearchResults(this.items);

                // Update inventory table if it exists
                const tableBody = document.querySelector('.inventory-table tbody');
                if (tableBody) {
                    if (this.items.length === 0) {
                        tableBody.innerHTML = '<tr class="no-items"><td colspan="8">No items in inventory</td></tr>';
                        return;
                    }

                    tableBody.innerHTML = this.items.map(item => `
                        <tr>
                            <td>${item.code || ''}</td>
                            <td>${item.name || ''}</td>
                            <td>${item.unit || 'PCS'}</td>
                            <td>${item.category || '-'}</td>
                            <td class="text-right">${item.costPrice ? item.costPrice.toFixed(2) : '0.00'}</td>
                            <td class="text-right">${item.sellingPrice ? item.sellingPrice.toFixed(2) : '0.00'}</td>
                            <td class="text-center">${item.stock || 0}</td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-danger" onclick="posManager.deleteInventoryItem('${item.id}')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('');
                }
            };

            request.onerror = () => {
                console.error('Error loading inventory:', request.error);
                Utils.showToast('Error loading inventory items', 'error');
            };
        } catch (error) {
            console.error('Error accessing inventory store:', error);
            Utils.showToast('Error accessing inventory', 'error');
        }
    }

    async addInventoryItem() {
        try {
            const form = document.getElementById('add-item-form');
            const code = document.getElementById('product-code').value.trim();
            const name = document.getElementById('product-name').value.trim();
            const category = document.getElementById('product-category').value;
            const unit = document.getElementById('product-unit').value;
            const costPrice = parseFloat(document.getElementById('product-cost-price').value);
            const sellingPrice = parseFloat(document.getElementById('product-selling-price').value);
            const stock = parseInt(document.getElementById('product-stock').value);

            if (!code || !name || !category || !unit || isNaN(costPrice) || isNaN(sellingPrice) || isNaN(stock)) {
                Utils.showToast('Please fill in all required fields', 'error');
                return;
            }

            const item = {
                id: code,
                code: code,
                name: name,
                category: category,
                unit: unit,
                costPrice: costPrice,
                sellingPrice: sellingPrice,
                stock: stock,
                dateAdded: new Date().toISOString()
            };

            const store = window.dbManager.getStore('inventory', 'readwrite');
            await store.add(item);

            // Update both inventory table and POS items
            await this.loadInventory();
            
            Utils.showToast('Product added successfully', 'success');
            Utils.closeModal();
            form.reset();

        } catch (error) {
            console.error('Error adding inventory item:', error);
            Utils.showToast('Error adding product', 'error');
        }
    }

    handleSearch() {
        try {
            const searchTerm = this.itemSearch.value.toLowerCase();
            const filteredItems = this.items.filter(item => 
                item.name.toLowerCase().includes(searchTerm) || 
                item.id.toString().includes(searchTerm)
            );
            this.displaySearchResults(filteredItems);
        } catch (error) {
            console.error('Error in search:', error);
            Utils.showToast('Error searching items', 'error');
        }
    }

    displaySearchResults(items) {
        if (!this.posItems) return;

        try {
            this.posItems.innerHTML = '';

            if (items.length === 0) {
                this.posItems.innerHTML = '<div class="no-results">No items found</div>';
                return;
            }

            const gridContainer = document.createElement('div');
            gridContainer.className = 'products-grid';

            items.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.className = 'search-result-item';
                itemElement.innerHTML = `
                    <div class="item-info">
                        <span class="item-name">${item.name}</span>
                        <span class="item-price">${item.sellingPrice.toFixed(2)}</span>
                    </div>
                    <button class="add-to-pos">
                        <i class="fas fa-plus"></i> Add
                    </button>
                `;
                
                const addButton = itemElement.querySelector('.add-to-pos');
                addButton.addEventListener('click', () => this.addItemToPOS(item.id));
                
                gridContainer.appendChild(itemElement);
            });

            this.posItems.appendChild(gridContainer);
        } catch (error) {
            console.error('Error displaying results:', error);
            Utils.showToast('Error displaying search results', 'error');
        }
    }

    async addItemToPOS(itemId, quickSaleItem = null) {
        try {
            let item = quickSaleItem;
            if (!item) {
                item = this.items.find(i => i.id === itemId);
                if (!item) {
                    // Try to fetch from database if not in memory
                    const store = window.dbManager.getStore('inventory', 'readonly');
                    item = await store.get(itemId);
                }
                if (!item) {
                    console.error('Item not found:', itemId);
                    Utils.showToast('Item not found', 'error');
                    return;
                }
            }

            // Ensure price is a valid number
            const price = parseFloat(item.sellingPrice) || 0;

            // Check if item already exists in cart
            const existingItem = this.itemsContainer.querySelector(`.pos-item input[value="${item.id}"]`);
            
            if (existingItem) {
                // If item exists, increase its quantity by 1
                const itemRow = existingItem.closest('.pos-item');
                const quantityInput = itemRow.querySelector('.item-quantity');
                const currentQuantity = parseInt(quantityInput.value) || 0;
                quantityInput.value = currentQuantity + 1;
                this.updateItemTotal(itemRow);
                // Play beep sound
                this.beepSound.play().catch(e => console.log('Error playing sound:', e));
                return;
            }

            // If item doesn't exist, add new row
            const row = document.createElement('div');
            row.className = 'pos-item';
            row.innerHTML = `
                <div class="item-row">
                    <input type="hidden" class="item-id" value="${item.id}">
                    <div class="item-name">${item.name}</div>
                    <input type="number" class="item-quantity" value="1" min="1">
                    <div class="item-unit">${item.unit || 'PCS'}</div>
                    <div class="item-price">${price.toFixed(2)}</div>
                    <div class="item-total">${price.toFixed(2)}</div>
                    <button class="btn btn-icon remove-item">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;

            // Add event listeners
            const quantityInput = row.querySelector('.item-quantity');
            quantityInput.addEventListener('input', () => this.updateItemTotal(row));

            const removeButton = row.querySelector('.remove-item');
            removeButton.addEventListener('click', () => {
                row.remove();
                this.calculateTotal();
            });

            this.itemsContainer.appendChild(row);
            this.calculateTotal();

            // Play beep sound
            this.beepSound.play().catch(e => console.log('Error playing sound:', e));

            // Add to items array if it's a quick sale item
            if (quickSaleItem && !this.items.find(i => i.id === quickSaleItem.id)) {
                this.items.push(quickSaleItem);
            }

            Utils.showToast('Item added to cart', 'success');
        } catch (error) {
            console.error('Error adding item:', error);
            Utils.showToast('Error adding item to cart', 'error');
        }
    }

    async addQuickSaleToCart(item) {
        try {
            const row = document.createElement('div');
            row.className = 'pos-item';
            row.innerHTML = `
                <div class="item-row">
                    <input type="hidden" class="item-id" value="${item.id}">
                    <div class="item-name">${item.name}</div>
                    <input type="number" class="item-quantity" value="1" min="1">
                    <div class="item-unit">${item.unit || 'PCS'}</div>
                    <div class="item-price">${item.sellingPrice.toFixed(2)}</div>
                    <div class="item-total">${item.sellingPrice.toFixed(2)}</div>
                    <button class="btn btn-icon remove-item">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;

            // Add event listeners
            const quantityInput = row.querySelector('.item-quantity');
            quantityInput.addEventListener('input', () => this.updateItemTotal(row));

            const removeButton = row.querySelector('.remove-item');
            removeButton.addEventListener('click', () => {
                row.remove();
                this.calculateTotal();
            });

            this.itemsContainer.appendChild(row);
            this.calculateTotal();

            // Play beep sound
            this.beepSound.play().catch(e => console.log('Error playing sound:', e));

            // Add to items array if not already present
            if (!this.items.find(i => i.id === item.id)) {
                this.items.push(item);
            }

            Utils.showToast('Item added to cart', 'success');
        } catch (error) {
            console.error('Error adding quick sale item to cart:', error);
            Utils.showToast('Error adding item to cart', 'error');
        }
    }

    updateItemTotal(row) {
        try {
            const quantity = parseFloat(row.querySelector('.item-quantity').value) || 0;
            const price = parseFloat(row.querySelector('.item-price').textContent) || 0;
            const total = quantity * price;
            
            row.querySelector('.item-total').textContent = total.toFixed(2);
            this.calculateTotal();
        } catch (error) {
            console.error('Error updating total:', error);
            Utils.showToast('Error updating item total', 'error');
        }
    }

    calculateTotal() {
        try {
            let subtotal = 0;
            const items = this.itemsContainer.querySelectorAll('.pos-item');
            
            items.forEach(item => {
                const total = parseFloat(item.querySelector('.item-total').textContent) || 0;
                subtotal += total;
            });

            // Update subtotal
            this.subtotalElement.textContent = subtotal.toFixed(2) + ' QAR';

            // Calculate discount
            const discountType = this.discountType.value;
            const discountInputValue = parseFloat(this.discountInput.value) || 0;
            let discountAmount = 0;

            if (discountType === 'percentage') {
                discountAmount = (subtotal * discountInputValue) / 100;
            } else {
                discountAmount = discountInputValue;
            }

            // Update discount and total
            this.discountValue.textContent = discountAmount.toFixed(2) + ' QAR';
            const total = subtotal - discountAmount;
            this.totalAmount.textContent = total.toFixed(2) + ' QAR';

            // Store current values
            this.currentSubtotal = subtotal;
            this.currentDiscount = discountAmount;
            this.currentTotal = total;

        } catch (error) {
            console.error('Error calculating total:', error);
            Utils.showToast('Error calculating total', 'error');
        }
    }

    clearCart() {
        try {
            if (this.itemsContainer) {
                this.itemsContainer.innerHTML = '';
                if (this.discountInput) {
                    this.discountInput.value = '0';
                }
                this.calculateTotal();
            }
        } catch (error) {
            console.error('Error clearing cart:', error);
            Utils.showToast('Error clearing cart', 'error');
        }
    }

    async processSale() {
        try {
            const items = Array.from(this.itemsContainer.querySelectorAll('.pos-item')).map(row => {
                const id = row.querySelector('.item-id').value;
                const name = row.querySelector('.item-name').textContent;
                const quantity = parseFloat(row.querySelector('.item-quantity').value);
                const price = parseFloat(row.querySelector('.item-price').textContent);
                const total = parseFloat(row.querySelector('.item-total').textContent);
                const unit = row.querySelector('.item-unit').textContent;
                return { id, name, quantity, price, total, unit };
            });

            if (items.length === 0) {
                Utils.showToast('Cart is empty', 'error');
                return;
            }

            const sale = {
                invoiceNumber: await this.generateInvoiceNumber(),
                items,
                subtotal: parseFloat(this.subtotalElement.textContent),
                discount: {
                    type: this.discountType.value,
                    value: parseFloat(this.discountValue.textContent) || 0
                },
                total: parseFloat(this.totalAmount.textContent),
                date: this.billDateInput ? this.billDateInput.value : new Date().toISOString().split('T')[0],
                customerName: this.customerNameInput ? this.customerNameInput.value : '',
                paymentMethod: this.selectedPaymentMethod,
                cashierName: document.getElementById('cashier-name').value || 'Admin'
            };

            // Log sale object for debugging
            console.log('Sale object:', sale);

            // Print receipt directly without saving to database
            this.printReceipt(sale);

            // Clear cart after successful sale
            this.clearCart();
            
            Utils.showToast('Sale completed successfully', 'success');
        } catch (error) {
            console.error('Error processing sale:', error);
            Utils.showToast('Error processing sale', 'error');
        }
    }

    generateInvoiceNumber() {
        const year = new Date().getFullYear();
        const randomNum = Math.floor(Math.random() * 100).toString().padStart(2, '0');
        return `AMT${year}${randomNum}`;
    }

    generateInvoiceTable(sale) {
        let tableRows = '';
        const items = sale.items || [];
        let serialNumber = 1;
        
        // Generate up to 25 rows, filling empty rows if needed
        for (let i = 0; i < 25; i++) {
            const item = items[i] || {};
            const rowClass = i % 2 === 0 ? '' : 'even';
            
            tableRows += `
                <tr class="${rowClass}">
                    <td style="text-align: center; padding-top: 4px; padding-bottom: 4px; font-weight: 600; height: 28px; vertical-align: middle;">${item.name ? serialNumber++ : ''}</td>
                    <td style="text-align: left; padding-top: 4px; padding-bottom: 4px; font-weight: 600; height: 28px; vertical-align: middle;">${item.name || ''}</td>
                    <td style="text-align: center; padding-top: 4px; padding-bottom: 4px; font-weight: 600; height: 28px; vertical-align: middle;">${item.quantity || ''}</td>
                    <td style="text-align: center; padding-top: 4px; padding-bottom: 4px; font-weight: 600; height: 28px; vertical-align: middle;">${item.unit || ''}</td>
                    <td style="text-align: right; padding-top: 4px; padding-bottom: 4px; font-weight: 600; height: 28px; vertical-align: middle;">${item.price ? item.price.toFixed(2) : ''}</td>
                    <td style="text-align: right; padding-top: 4px; padding-bottom: 4px; font-weight: 600; height: 28px; vertical-align: middle;">${item.total ? item.total.toFixed(2) : ''}</td>
                </tr>
            `;
        }
        
        return `
            <table style="width: 100%; border-collapse: collapse; margin: 8px 0;">
                <thead>
                    <tr>
                        <th style="background-color: var(--primary-color); color: white; text-align: center; padding: 6px; font-size: 11px; font-weight: 700; border: 1px solid #ddd; width: 5%; height: 28px; vertical-align: middle;">S.No</th>
                        <th style="background-color: var(--primary-color); color: white; text-align: left; padding: 6px; font-size: 11px; font-weight: 700; border: 1px solid #ddd; width: 40%; height: 28px; vertical-align: middle;">Description</th>
                        <th style="background-color: var(--primary-color); color: white; text-align: center; padding: 6px; font-size: 11px; font-weight: 700; border: 1px solid #ddd; width: 10%; height: 28px; vertical-align: middle;">Qty</th>
                        <th style="background-color: var(--primary-color); color: white; text-align: center; padding: 6px; font-size: 11px; font-weight: 700; border: 1px solid #ddd; width: 15%; height: 28px; vertical-align: middle;">Unit</th>
                        <th style="background-color: var(--primary-color); color: white; text-align: right; padding: 6px; font-size: 11px; font-weight: 700; border: 1px solid #ddd; width: 15%; height: 28px; vertical-align: middle;">Price</th>
                        <th style="background-color: var(--primary-color); color: white; text-align: right; padding: 6px; font-size: 11px; font-weight: 700; border: 1px solid #ddd; width: 15%; height: 28px; vertical-align: middle;">Total</th>
                    </tr>
                </thead>
                <tbody style="border: 1px solid #ddd;">
                    ${tableRows}
                </tbody>
            </table>
        `;
    }
    getInvoiceTitle(paymentMethod) {
        switch(paymentMethod.toLowerCase()) {
            case 'credit':
                return 'CREDIT INVOICE';
            case 'bank':
                return 'BANK TRANSFER';
            case 'card':
                return 'CARD PAYMENT';
            case 'cash':
            default:
                return 'CASH INVOICE';
        }
    }

    getStyles() {
        return `
            .invoice-container {
                margin: 0 auto;
                width: 210mm;
                min-height: 297mm;
                background: white;
                position: relative;
                padding: 1mm;
                box-sizing: border-box;
            }

            .invoice-header {
                display: flex;
                flex-direction: column;
                align-items: center;
                margin-bottom: 1px;
                padding: 4px;
                border-bottom: 1px solid var(--primary-color);
                background: #e8eaf6;
                border-radius: 4px;
            }

            .shop-name {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin: 0;
                padding: 0;
                border-bottom: 1px solid #ddd;
                width: 100%;
            }

            .english-name {
                font-size: 24px;
                font-weight: 700;
                margin: 0;
                padding: 0;
                letter-spacing: 1.5px;
                color: var(--primary-color);
                text-align: left;
                flex: 1;
            }

            .arabic-name {
                font-size: 32px;
                font-weight: 700;
                margin: 0;
                padding: 0;
                letter-spacing: 1px;
                color: var(--primary-color);
                text-align: right;
                direction: rtl;
                flex: 1;
                font-family: 'Noto Naskh Arabic', sans-serif;
            }

            .header-content {
                display: flex;
                width: 100%;
                justify-content: space-between;
                align-items: flex-start;
                margin-top: 5px;
            }

            .header-left {
                flex: 1;
                padding: 0 15px;
            }

            .header-center {
                flex: 1;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
            }

            .header-right {
                flex: 1;
                padding: 0 15px;
                text-align: right;
                direction: rtl;
                min-width: 200px;
            }

            .contact-info {
                font-size: 11px;
                line-height: 1.2;
                color: var(--text-color);
                font-weight: 600;
                margin: 0;
                padding: 0;
            }

            .contact-info p {
                margin: 0;
                padding: 0;
            }

            .contact-info.arabic {
                font-size: 11px;
                font-weight: 600;
                text-align: right;
                direction: rtl;
                line-height: 1.2;
                font-family: 'Noto Naskh Arabic', sans-serif;
            }

            .logo-container {
                width: 100px;
                height: 100px;
                margin: 0 auto;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .logo {
                width: 100%;
                height: 100%;
                object-fit: contain;
            }

            .cash-invoice-label {
                font-size: 12px;
                font-weight: 600;
                color: white;
                background: var(--primary-color);
                padding: 3px 10px;
                border-radius: 4px;
                margin-top: 5px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                display: inline-block;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                white-space: nowrap;
            }

            .meta-section {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin: 1px 1px;
                padding: 2px 6px;
                background: var(--light-bg);
                border-radius: 2px;
            }

            .invoice-meta, .date-info {
                font-size: 11px;
                line-height: 1.2;
                margin: 0;
                padding: 0;
            }

            .invoice-meta p, .date-info p {
                margin: 0;
                padding: 0;
            }

            .meta-label {
                font-weight: 700;
                color: var(--primary-color);
                display: inline-block;
                min-width: 65px;
            }

            .meta-value {
                font-weight: 600;
                color: var(--text-color);
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin: 8px 0;
            }

            th, td {
                text-align: left;
                padding: 2px 4px;
                border: 1px solid #ddd;
                font-size: 11px;
                line-height: 1.2;
            }

            th {
                background-color: var(--primary-color);
                color: white;
                font-weight: 600;
            }

            tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .total-section {
                width: 100%;
                margin: 4px 0;
                padding: 4px;
                border: 1px solid var(--primary-color);
                border-radius: 3px;
                background-color: var(--light-bg);
            }

            .amounts-container {
                display: flex;
                justify-content: space-between;
                gap: 4px;
            }

            .written-amount {
                flex: 1;
                padding-right: 8px;
            }

            .written-amount p {
                margin: 0;
                font-size: 11px;
                color: var(--text-color);
                font-weight: 600;
                line-height: 1.1;
            }

            .written-amount .words {
                font-weight: 700;
                color: var(--primary-color);
                margin: 0;
                font-size: 11px;
                text-transform: uppercase;
                line-height: 1.1;
            }

            .numeric-totals {
                min-width: 200px;
            }

            .total-row {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin: 0;
                padding: 0;
                line-height: 1.2;
            }

            .total-label {
                font-weight: 700;
                color: var(--text-color);
                margin-right: 10px;
                font-size: 12px;
            }

            .total-value {
                font-weight: 700;
                color: var(--primary-color);
                text-align: right;
                min-width: 90px;
                font-size: 12px;
            }

            .total-row:last-child {
                margin-top: 1px;
                padding-top: 1px;
                border-top: 1px solid var(--primary-color);
            }

            .total-row:last-child .total-label,
            .total-row:last-child .total-value {
                font-size: 13px;
                font-weight: 800;
            }

            .signature-section {
                margin: 3px 0;
                padding: 3px;
                border: 1px solid var(--primary-color);
                border-radius: 3px;
                text-align: center;
                min-height: 40px;
                display: flex;
                flex-direction: column;
                justify-content: flex-end;
            }

            .signature-line {
                font-size: 10px;
                color: var(--text-color);
                margin: 0;
                font-weight: 600;
                white-space: nowrap;
                padding-top: 20px;
                border-top: 1px dashed #999;
                margin-top: 10px;
            }

            .signature-line .dot-line {
                display: inline-block;
                width: 150px;
                margin: 0 4px;
            }

            .signature-spacer {
                display: inline-block;
                width: 40px;
            }

            .footer-section {
                margin: 3px 0;
                padding: 3px;
                text-align: center;
                border: 1px solid var(--primary-color);
                border-radius: 3px;
            }

            .footer-text {
                font-size: 10px;
                color: var(--text-color);
                margin: 0;
                line-height: 1.2;
            }

            @media print {
                @page {
                    size: A4;
                    margin: 10mm;
                }
                body {
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                }
                .no-print {
                    display: none !important;
                }
            }
        `;
    }

    generateInvoiceContent(sale) {
        const formattedDate = new Date(sale.date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        return `
            <div class="invoice-header">
                <div class="shop-name">
                    <h1 class="english-name">AL MISBAH TRADING EST</h1>
                    <h1 class="arabic-name">المصباح للتجارة م.م</h1>
                </div>
                <div class="header-content">
                    <div class="header-left">
                        <div class="contact-info">
                            <p>Tel: +974 50747726/55254811</p>
                            <p>E-mail: almisbahmesaieed2015@gmail.com</p>
                            <p>New Souq, Building: 123</p>
                            <p>Shop: AS24</p>
                            <p>Mesaieed, Qatar</p>
                            <p>CR No: 10442/9</p>
                        </div>
                    </div>
                    <div class="header-center">
                        <div class="logo-container">
                            <img src="assets/Images/AMT-LOGO.png" alt="AL MISBAH TRADING" class="logo" onerror="this.style.display='none'">
                        </div>
                        <div class="cash-invoice-label">${this.getInvoiceTitle(sale.paymentMethod)}</div>
                    </div>
                    <div class="header-right">
                        <div class="contact-info arabic">
                            <p>تليفون: +٩٧٤ ٥٠٧٤٧٧٢٦ / ٥٥٢٥٤٨١١</p>
                            <p>البريد الإلكتروني: almisbahmesaieed2015@gmail.com</p>
                            <p>السوق الجديد، المبنى: ١٢٣</p>
                            <p>المحل: AS24</p>
                            <p>مسيعيد، قطر</p>
                            <p>رقم السجل التجاري: ١٠٤٤٢/٩</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="meta-section">
                <div class="invoice-meta">
                    <p><span class="meta-label">Invoice #:</span> <span class="meta-value">${sale.invoiceNumber}</span></p>
                    ${sale.customerName ? `<p><span class="meta-label">Customer:</span> <span class="meta-value">${sale.customerName}</span></p>` : ''}
                </div>
                <div class="date-info">
                    <p><span class="meta-label">Cashier:</span> <span class="meta-value">${sale.cashierName}</span></p>
                    <p><span class="meta-label">Date:</span> <span class="meta-value">${formattedDate}</span></p>
                </div>
            </div>

            ${this.generateInvoiceTable(sale)}
            
            <div class="total-section">
                <div class="amounts-container">
                    <div class="written-amount">
                        <p><strong>Amount in Words:</strong></p>
                        <p class="words">${this.numberToWords(Math.round(sale.total))} QATARI RIYALS ONLY</p>
                    </div>
                    <div class="numeric-totals">
                        <div class="total-row">
                            <span class="total-label">Sub Total:</span>
                            <span class="total-value">QAR ${sale.subtotal.toFixed(2)}</span>
                        </div>
                        <div class="total-row">
                            <span class="total-label">Discount:</span>
                            <span class="total-value">QAR ${sale.discount.value.toFixed(2)}</span>
                        </div>
                        <div class="total-row">
                            <span class="total-label">Total Amount:</span>
                            <span class="total-value">QAR ${sale.total.toFixed(2)}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="signature-section">
                <div class="signature-line">
                    Seller Signature / توقيع البائع <span class="dot-line"></span>
                    <span class="signature-spacer"></span>
                    Receiver Signature / توقيع المستلم <span class="dot-line"></span>
                </div>
            </div>

            <div class="footer-section">
                <div class="footer-text">
                    <p>Thank you for your business! | !شكرا لتعاملكم معنا</p>
                    <p>For any queries, please contact us at: +974 50747726/55254811 | ٥٥٢٥٤٨١١/للاستفسارات يرجى الاتصال على: ٥٠٧٤٧٧٢٦</p>
                </div>
            </div>
        `;
    }

    printReceipt(sale) {
        // Create a new window for printing
        const printWindow = window.open('', '_blank', 'width=800,height=600');
        
        if (!printWindow) {
            alert('Please allow popups to print the invoice');
            return;
        }

        // Write the complete HTML document to the new window
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Invoice #${sale.invoiceNumber}</title>
                <meta charset="UTF-8">
                <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
                <style>
                    :root {
                        --primary-color: #1a237e;
                        --secondary-color: #303f9f;
                        --accent-color: #3949ab;
                        --text-color: #333;
                        --light-bg: #f5f6fa;
                    }
                    
                    @media print {
                        @page {
                            size: A4;
                            margin: 10mm;
                        }
                        body {
                            -webkit-print-color-adjust: exact !important;
                            print-color-adjust: exact !important;
                        }
                        .no-print {
                            display: none !important;
                        }
                    }

                    * {
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box;
                    }

                    body {
                        font-family: 'Poppins', sans-serif;
                        line-height: 1.4;
                        color: var(--text-color);
                        background: #f0f0f0;
                        padding: 20px;
                    }

                    .preview-controls {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        display: flex;
                        gap: 10px;
                        z-index: 1000;
                    }

                    .preview-button {
                        padding: 8px 16px;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        font-family: 'Poppins', sans-serif;
                        font-weight: 500;
                        font-size: 14px;
                        transition: all 0.3s ease;
                    }

                    .print-btn {
                        background-color: var(--primary-color);
                        color: white;
                    }

                    .print-btn:hover {
                        background-color: var(--secondary-color);
                    }

                    .close-btn {
                        background-color: #dc3545;
                        color: white;
                    }

                    .close-btn:hover {
                        background-color: #c82333;
                    }

                    ${this.getStyles()}
                </style>
            </head>
            <body>
                <div class="preview-controls no-print">
                    <button class="preview-button print-btn" onclick="printInvoice()">Print</button>
                    <button class="preview-button close-btn" onclick="window.close()">Close</button>
                </div>
                <div class="invoice-container">
                    ${this.generateInvoiceContent(sale)}
                </div>
                <script>
                    function printInvoice() {
                        window.print();
                    }
                </script>
            </body>
            </html>
        `);
        
        // Close the document
        printWindow.document.close();
    }

    updateInvoiceList() {
        if (!this.invoiceListBody) return;

        const query = this.invoiceSearch ? this.invoiceSearch.value : '';
        const fromDate = this.invoiceDateFrom ? this.invoiceDateFrom.value : null;
        const toDate = this.invoiceDateTo ? this.invoiceDateTo.value : null;

        try {
            const invoices = this.searchInvoices(query, fromDate, toDate);
            this.invoiceListBody.innerHTML = '';

            invoices.forEach(invoice => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${invoice.invoiceNumber}</td>
                    <td>${new Date(invoice.date).toLocaleDateString()}</td>
                    <td>${invoice.customerName || '-'}</td>
                    <td>${invoice.paymentMethod.toUpperCase()}</td>
                    <td>QAR ${invoice.total.toFixed(2)}</td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="window.posManager.reprintInvoice('${invoice.invoiceNumber}')">
                            <i class="fas fa-print"></i> Reprint
                        </button>
                    </td>
                `;
                this.invoiceListBody.appendChild(row);
            });
        } catch (error) {
            console.error('Error updating invoice list:', error);
            Utils.showToast('Error loading invoices', 'error');
        }
    }

    async reprintInvoice(invoiceNumber) {
        try {
            const invoice = await this.getInvoice(invoiceNumber);
            if (invoice) {
                this.printReceipt(invoice);
            } else {
                Utils.showToast('Invoice not found', 'error');
            }
        } catch (error) {
            console.error('Error reprinting invoice:', error);
            Utils.showToast('Error reprinting invoice', 'error');
        }
    }

    showQuickSaleModal() {
        const modal = document.getElementById('quick-sale-modal');
        modal.style.display = 'block';

        // Reset form
        const form = document.getElementById('quick-sale-form');
        form.reset();

        // Handle form submission
        form.onsubmit = async (e) => {
            e.preventDefault();
            
            try {
                const code = document.getElementById('quick-sale-code').value.trim();
                const name = document.getElementById('quick-sale-name').value.trim();
                const category = document.getElementById('quick-sale-category').value;
                const unit = document.getElementById('quick-sale-unit').value;
                const costPrice = parseFloat(document.getElementById('quick-sale-cost-price').value);
                const sellingPrice = parseFloat(document.getElementById('quick-sale-selling-price').value);
                const stock = parseInt(document.getElementById('quick-sale-stock').value);

                if (!code || !name || !category || !unit || isNaN(costPrice) || isNaN(sellingPrice) || isNaN(stock)) {
                    Utils.showToast('Please fill in all required fields', 'error');
                    return;
                }

                const item = {
                    id: code,
                    code: code,
                    name: name,
                    category: category,
                    unit: unit,
                    costPrice: costPrice,
                    sellingPrice: sellingPrice,
                    stock: stock,
                    dateAdded: new Date().toISOString()
                };

                const store = window.dbManager.getStore('inventory', 'readwrite');
                await store.add(item);

                // Update both inventory table and POS items
                await this.loadInventory();
                
                // Close modal and show success message
                modal.style.display = 'none';
                Utils.showToast('Item added successfully', 'success');

                // Play beep sound
                this.beepSound.play();
            } catch (error) {
                console.error('Error adding quick sale item:', error);
                Utils.showToast('Error adding item', 'error');
            }
        };

        // Close modal when clicking outside
        window.onclick = (event) => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        };
    }

    showAddItemModal() {
        const modalTitle = document.getElementById('modal-title');
        const modalContainer = document.querySelector('.modal-container');
        const addItemForm = document.getElementById('add-item-form');

        if (modalTitle && modalContainer && addItemForm) {
            modalTitle.textContent = 'Add New Item';
            modalContainer.style.display = 'flex';
            
            // Remove any existing event listeners
            addItemForm.removeEventListener('submit', this.handleFormSubmit);
            
            // Add new event listener
            this.handleFormSubmit = async (e) => {
                e.preventDefault();
                await this.addInventoryItem();
            };
            
            addItemForm.addEventListener('submit', this.handleFormSubmit);
        }
    }

    async addInventoryItem() {
        try {
            const form = document.getElementById('add-item-form');
            const code = document.getElementById('product-code').value.trim();
            const name = document.getElementById('product-name').value.trim();
            const category = document.getElementById('product-category').value;
            const unit = document.getElementById('product-unit').value;
            const costPrice = parseFloat(document.getElementById('product-cost-price').value);
            const sellingPrice = parseFloat(document.getElementById('product-selling-price').value);
            const stock = parseInt(document.getElementById('product-stock').value);

            if (!code || !name || !category || !unit || isNaN(costPrice) || isNaN(sellingPrice) || isNaN(stock)) {
                Utils.showToast('Please fill in all required fields', 'error');
                return;
            }

            const item = {
                id: code,
                code: code,
                name: name,
                category: category,
                unit: unit,
                costPrice: costPrice,
                sellingPrice: sellingPrice,
                stock: stock,
                dateAdded: new Date().toISOString()
            };

            const store = window.dbManager.getStore('inventory', 'readwrite');
            await store.add(item);

            // Update both inventory table and POS items
            await this.loadInventory();
            
            Utils.showToast('Product added successfully', 'success');
            Utils.closeModal();
            form.reset();

        } catch (error) {
            console.error('Error adding inventory item:', error);
            Utils.showToast('Error adding product', 'error');
        }
    }
}

// Initialize POS manager
window.addEventListener('DOMContentLoaded', () => {
    window.posManager = new POSManager();
});

// Add print-specific styles
const style = document.createElement('style');
style.innerHTML = `
    @media print {
        @page {
            size: A4;
            margin: 0;
        }
        
        body {
            margin: 0;
            padding: 0;
            background: white !important;
        }

        body * {
            visibility: hidden;
        }

        #printSection, #printSection * {
            visibility: visible;
        }

        #printSection {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 20mm;
            box-sizing: border-box;
        }

        .no-print {
            display: none !important;
        }
    }

    .item-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 4px;
        background-color: #f8f9fa;
        border-radius: 4px;
    }

    .item-table tr {
        border: 1px solid #e2e8f0;
    }

    .item-table td {
        padding: 8px;
        vertical-align: middle;
    }

    .item-name {
        width: 40%;
        font-weight: 500;
    }

    .item-quantity-cell {
        width: 15%;
    }

    .item-quantity {
        width: 60px;
        padding: 4px;
        border: 1px solid #ddd;
        border-radius: 4px;
        text-align: center;
    }

    .item-price, .item-total {
        width: 20%;
        text-align: right;
        font-weight: 500;
    }

    .item-action {
        width: 5%;
        text-align: center;
    }

    .remove-item {
        padding: 4px 8px;
        color: #dc3545;
        background: none;
        border: none;
        cursor: pointer;
        transition: color 0.2s;
    }

    .remove-item:hover {
        color: #bd2130;
    }

    #cart-items {
        background-color: white;
        border-radius: 8px;
        padding: 12px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .pos-item {
        margin-bottom: 4px;
    }

    .pos-item:last-child {
        margin-bottom: 0;
    }

    .header-right {
        flex: 1;
        padding: 0 15px;
        text-align: right;
        direction: rtl;
        min-width: 200px;
    }

    .contact-info {
        margin-bottom: 3px;
    }

    .shop-details {
        margin: 0;
        padding: 0;
    }
`;
document.head.appendChild(style);

// Menu Toggle Functionality
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menu-toggle');
    const sideMenu = document.getElementById('side-menu');
    const mainContainer = document.getElementById('main-container');

    menuToggle.addEventListener('click', function() {
        menuToggle.classList.toggle('active');
        sideMenu.classList.toggle('active');
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!sideMenu.contains(event.target) && !menuToggle.contains(event.target) && sideMenu.classList.contains('active')) {
            menuToggle.classList.remove('active');
            sideMenu.classList.remove('active');
        }
    });

    // Close menu after selecting a tab
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            menuToggle.classList.remove('active');
            sideMenu.classList.remove('active');
        });
    });
});
