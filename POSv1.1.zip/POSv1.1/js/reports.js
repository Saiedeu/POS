class ReportsManager {
    constructor() {
        this.init();
    }

    init() {
        this.bindElements();
        this.bindEvents();
        this.initializeReports();
    }

    bindElements() {
        // Report type selector
        this.reportTypeSelect = document.querySelector('#report-type');
        this.dateRangeStart = document.querySelector('#date-range-start');
        this.dateRangeEnd = document.querySelector('#date-range-end');
        this.generateReportBtn = document.querySelector('#generate-report-btn');
        this.reportContainer = document.querySelector('#report-container');

        // Charts containers
        this.salesChartCanvas = document.querySelector('#sales-chart');
        this.productChartCanvas = document.querySelector('#product-chart');
        this.clientChartCanvas = document.querySelector('#client-chart');

        // Set default date range (current month)
        const now = new Date();
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        
        if (this.dateRangeStart && this.dateRangeEnd) {
            this.dateRangeStart.value = firstDay.toISOString().split('T')[0];
            this.dateRangeEnd.value = lastDay.toISOString().split('T')[0];
        }
    }

    bindEvents() {
        if (this.generateReportBtn) {
            this.generateReportBtn.addEventListener('click', () => this.generateReport());
        }
        if (this.reportTypeSelect) {
            this.reportTypeSelect.addEventListener('change', () => this.handleReportTypeChange());
        }
    }

    async initializeReports() {
        try {
            await this.generateReport();
        } catch (error) {
            console.error('Error initializing reports:', error);
            Utils.showToast('Error initializing reports', 'error');
        }
    }

    handleReportTypeChange() {
        this.generateReport();
    }

    async generateReport() {
        if (!this.reportTypeSelect || !this.dateRangeStart || !this.dateRangeEnd) {
            console.error('Required elements not found');
            return;
        }

        const reportType = this.reportTypeSelect.value;
        const startDate = new Date(this.dateRangeStart.value);
        const endDate = new Date(this.dateRangeEnd.value);

        try {
            switch (reportType) {
                case 'sales':
                    await this.generateSalesReport(startDate, endDate);
                    break;
                case 'products':
                    await this.generateProductReport(startDate, endDate);
                    break;
                case 'clients':
                    await this.generateClientReport(startDate, endDate);
                    break;
            }
            Utils.showToast('Report generated successfully', 'success');
        } catch (error) {
            console.error('Error generating report:', error);
            Utils.showToast('Error generating report', 'error');
        }
    }

    async generateSalesReport(startDate, endDate) {
        try {
            const store = window.dbManager.getStore('sales', 'readonly');
            const request = store.getAll();

            request.onsuccess = (event) => {
                const sales = event.target.result.filter(sale => {
                    const saleDate = new Date(sale.date);
                    return saleDate >= startDate && saleDate <= endDate;
                });

                const dailySales = this.aggregateDailySales(sales);
                const totalSales = sales.reduce((sum, s) => sum + s.total, 0);
                const averageSale = totalSales / (sales.length || 1);

                // Generate summary
                const summary = `
                    <div class="report-summary">
                        <h3>Sales Summary (${Utils.formatDate(startDate)} - ${Utils.formatDate(endDate)})</h3>
                        <div class="summary-grid">
                            <div class="summary-item">
                                <span class="label">Total Sales</span>
                                <span class="value">${Utils.formatCurrency(totalSales)}</span>
                            </div>
                            <div class="summary-item">
                                <span class="label">Total Transactions</span>
                                <span class="value">${sales.length}</span>
                            </div>
                            <div class="summary-item">
                                <span class="label">Average Sale</span>
                                <span class="value">${Utils.formatCurrency(averageSale)}</span>
                            </div>
                        </div>
                    </div>
                `;

                // Create sales chart
                this.createSalesChart(dailySales);

                // Generate detailed table
                const details = `
                    <div class="report-details">
                        <h3>Transaction Details</h3>
                        <table class="report-table" id="transactions-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Bill Number</th>
                                    <th>Items</th>
                                    <th>Total Amount</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${sales.map(sale => {
                                    // Generate a consistent invoice number for each sale
                                    const saleDate = new Date(sale.date);
                                    const invoiceNumber = `AMT${saleDate.getFullYear()}${String(Math.floor(Math.random() * 100)).padStart(2, '0')}`;
                                    
                                    return `
                                    <tr>
                                        <td>${saleDate.toLocaleDateString()}</td>
                                        <td>${saleDate.toLocaleTimeString()}</td>
                                        <td>${invoiceNumber}</td>
                                        <td>${sale.items.length} items</td>
                                        <td>${Utils.formatCurrency(sale.total)}</td>
                                        <td>
                                            <button class="btn btn-icon" onclick="reportsManager.viewTransaction('${sale.id}', '${invoiceNumber}')">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-icon" onclick="reportsManager.printTransaction('${sale.id}', '${invoiceNumber}')">
                                                <i class="fas fa-print"></i>
                                            </button>
                                        </td>
                                    </tr>
                                `}).join('')}
                            </tbody>
                        </table>
                    </div>
                `;

                if (this.reportContainer) {
                    this.reportContainer.innerHTML = summary + details;
                }
            };

            request.onerror = (event) => {
                console.error('Error fetching sales:', event.target.error);
                Utils.showToast('Error generating sales report', 'error');
            };
        } catch (error) {
            console.error('Error generating sales report:', error);
            Utils.showToast('Error generating sales report', 'error');
        }
    }

    async generateProductReport(startDate, endDate) {
        try {
            const quotations = await this.getQuotationsInRange(startDate, endDate);
            const productStats = this.aggregateProductStats(quotations);
            
            // Sort products by quantity sold
            const sortedProducts = Object.entries(productStats)
                .sort((a, b) => b[1].quantity - a[1].quantity);

            // Generate summary
            const summary = `
                <div class="report-summary">
                    <h3>Product Performance (${Utils.formatDate(startDate)} - ${Utils.formatDate(endDate)})</h3>
                    <div class="summary-grid">
                        <div class="summary-item">
                            <span class="label">Total Products Sold</span>
                            <span class="value">${sortedProducts.reduce((sum, [_, stats]) => sum + stats.quantity, 0)}</span>
                        </div>
                        <div class="summary-item">
                            <span class="label">Total Revenue</span>
                            <span class="value">${Utils.formatCurrency(sortedProducts.reduce((sum, [_, stats]) => sum + stats.revenue, 0))}</span>
                        </div>
                    </div>
                </div>
            `;

            // Create product performance chart
            this.createProductChart(sortedProducts);

            // Generate detailed table
            const details = `
                <div class="report-details">
                    <h3>Product Details</h3>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity Sold</th>
                                <th>Revenue</th>
                                <th>Average Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${sortedProducts.map(([code, stats]) => `
                                <tr>
                                    <td>${stats.name}</td>
                                    <td>${stats.quantity}</td>
                                    <td>${Utils.formatCurrency(stats.revenue)}</td>
                                    <td>${Utils.formatCurrency(stats.revenue / stats.quantity)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;

            if (this.reportContainer) {
                this.reportContainer.innerHTML = summary + details;
            }
        } catch (error) {
            console.error('Error generating product report:', error);
            Utils.showToast('Error generating product report', 'error');
        }
    }

    async generateClientReport(startDate, endDate) {
        try {
            const quotations = await this.getQuotationsInRange(startDate, endDate);
            const clientStats = this.aggregateClientStats(quotations);
            
            // Sort clients by total purchase amount
            const sortedClients = Object.entries(clientStats)
                .sort((a, b) => b[1].total - a[1].total);

            // Generate summary
            const summary = `
                <div class="report-summary">
                    <h3>Client Analysis (${Utils.formatDate(startDate)} - ${Utils.formatDate(endDate)})</h3>
                    <div class="summary-grid">
                        <div class="summary-item">
                            <span class="label">Total Clients</span>
                            <span class="value">${sortedClients.length}</span>
                        </div>
                        <div class="summary-item">
                            <span class="label">Average Purchase</span>
                            <span class="value">${Utils.formatCurrency(sortedClients.reduce((sum, [_, stats]) => sum + stats.total, 0) / sortedClients.length || 0)}</span>
                        </div>
                    </div>
                </div>
            `;

            // Create client performance chart
            this.createClientChart(sortedClients);

            // Generate detailed table
            const details = `
                <div class="report-details">
                    <h3>Client Details</h3>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Client</th>
                                <th>Quotations</th>
                                <th>Total Purchase</th>
                                <th>Average Purchase</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${sortedClients.map(([name, stats]) => `
                                <tr>
                                    <td>${name}</td>
                                    <td>${stats.count}</td>
                                    <td>${Utils.formatCurrency(stats.total)}</td>
                                    <td>${Utils.formatCurrency(stats.total / stats.count)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;

            if (this.reportContainer) {
                this.reportContainer.innerHTML = summary + details;
            }
        } catch (error) {
            console.error('Error generating client report:', error);
            Utils.showToast('Error generating client report', 'error');
        }
    }

    async getQuotationsInRange(startDate, endDate) {
        try {
            const quotations = await DB.getAll('quotations');
            return quotations.filter(q => {
                const quotationDate = new Date(q.date);
                return quotationDate >= startDate && quotationDate <= endDate;
            });
        } catch (error) {
            console.error('Error fetching quotations:', error);
            return [];
        }
    }

    aggregateDailySales(sales) {
        const dailySales = {};
        sales.forEach(sale => {
            const date = new Date(sale.date).toLocaleDateString();
            dailySales[date] = (dailySales[date] || 0) + sale.total;
        });
        return dailySales;
    }

    aggregateProductStats(quotations) {
        const productStats = {};

        quotations.forEach(quotation => {
            quotation.items.forEach(item => {
                if (!productStats[item.productCode]) {
                    productStats[item.productCode] = {
                        name: item.productName || 'Unknown Product',
                        quantity: 0,
                        revenue: 0
                    };
                }
                productStats[item.productCode].quantity += item.quantity;
                productStats[item.productCode].revenue += item.quantity * item.price;
            });
        });

        return productStats;
    }

    aggregateClientStats(quotations) {
        const clientStats = {};

        quotations.forEach(quotation => {
            const clientName = quotation.clientName;
            if (!clientStats[clientName]) {
                clientStats[clientName] = {
                    count: 0,
                    total: 0
                };
            }
            clientStats[clientName].count++;
            clientStats[clientName].total += quotation.total;
        });

        return clientStats;
    }

    createSalesChart(dailySales) {
        if (!this.salesChartCanvas) return;

        const ctx = this.salesChartCanvas.getContext('2d');
        const dates = Object.keys(dailySales).sort();
        const sales = dates.map(date => dailySales[date]);

        if (this.salesChart) {
            this.salesChart.destroy();
        }

        this.salesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates.map(date => Utils.formatDate(date)),
                datasets: [{
                    label: 'Daily Sales',
                    data: sales,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => Utils.formatCurrency(value)
                        }
                    }
                }
            }
        });
    }

    createProductChart(productStats) {
        if (!this.productChartCanvas) return;

        const ctx = this.productChartCanvas.getContext('2d');
        const topProducts = productStats.slice(0, 10);

        if (this.productChart) {
            this.productChart.destroy();
        }

        this.productChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: topProducts.map(([_, stats]) => stats.name),
                datasets: [{
                    label: 'Quantity Sold',
                    data: topProducts.map(([_, stats]) => stats.quantity),
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgb(75, 192, 192)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    createClientChart(clientStats) {
        if (!this.clientChartCanvas) return;

        const ctx = this.clientChartCanvas.getContext('2d');
        const topClients = clientStats.slice(0, 10);

        if (this.clientChart) {
            this.clientChart.destroy();
        }

        this.clientChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: topClients.map(([name]) => name),
                datasets: [{
                    label: 'Total Purchase',
                    data: topClients.map(([_, stats]) => stats.total),
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgb(153, 102, 255)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => Utils.formatCurrency(value)
                        }
                    }
                }
            }
        });
    }

    async viewTransaction(saleId, invoiceNumber) {
        try {
            const store = window.dbManager.getStore('sales', 'readonly');
            const request = store.get(saleId);

            request.onsuccess = (event) => {
                const sale = event.target.result;
                if (!sale) {
                    Utils.showToast('Transaction not found', 'error');
                    return;
                }

                const modalContent = `
                    <div class="transaction-details print-area">
                        <div class="bill-header">
                            <h2>AL MISBAH TRADING</h2>
                            <p>Building Materials & Hardware</p>
                            <p>Wholesale & Retail</p>
                            <p>TRN: 100534080700003</p>
                            <p>Tel: +971 6 5344330</p>
                            <p>Sharjah, United Arab Emirates</p>
                        </div>
                        <div class="separator"></div>
                        <div class="transaction-info">
                            <p><strong>Bill Number:</strong> ${invoiceNumber}</p>
                            <p><strong>Date:</strong> ${new Date(sale.date).toLocaleDateString()}</p>
                            <p><strong>Time:</strong> ${new Date(sale.date).toLocaleTimeString()}</p>
                        </div>
                        <div class="separator"></div>
                        <table class="bill-items">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${sale.items.map(item => `
                                    <tr>
                                        <td>${item.name}</td>
                                        <td>${item.quantity}</td>
                                        <td>${Utils.formatCurrency(item.price)}</td>
                                        <td>${Utils.formatCurrency(item.total)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                        <div class="separator"></div>
                        <div class="bill-total">
                            <p>
                                <span>Total Amount:</span>
                                <span>${Utils.formatCurrency(sale.total)}</span>
                            </p>
                        </div>
                        <div class="separator"></div>
                        <div class="bill-footer">
                            <p>Thank you for your business!</p>
                            <p>Please visit again</p>
                        </div>
                        <div class="modal-footer no-print">
                            <button class="btn btn-primary" onclick="reportsManager.printTransaction('${sale.id}', '${invoiceNumber}')">
                                <i class="fas fa-print"></i> Print Bill
                            </button>
                            <button class="btn btn-secondary" onclick="Utils.closeModal()">Close</button>
                        </div>
                    </div>
                `;

                Utils.openModal('Transaction Details', modalContent);
            };

            request.onerror = (event) => {
                console.error('Error fetching transaction:', event.target.error);
                Utils.showToast('Error viewing transaction', 'error');
            };
        } catch (error) {
            console.error('Error viewing transaction:', error);
            Utils.showToast('Error viewing transaction details', 'error');
        }
    }

    async printTransaction(saleId, invoiceNumber) {
        try {
            const store = window.dbManager.getStore('sales', 'readonly');
            const request = store.get(saleId);

            request.onsuccess = (event) => {
                const sale = event.target.result;
                if (!sale) {
                    Utils.showToast('Transaction not found', 'error');
                    return;
                }

                const printWindow = window.open('', '_blank');
                printWindow.document.write(`
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Bill - ${invoiceNumber}</title>
                        <style>
                            @media print {
                                body * {
                                    visibility: hidden;
                                }
                                
                                .print-area,
                                .print-area * {
                                    visibility: visible;
                                }
                                
                                .print-area {
                                    position: absolute;
                                    left: 0;
                                    top: 0;
                                    width: 80mm;
                                    padding: 10px;
                                    font-family: 'Courier New', monospace;
                                    font-size: 12px;
                                }

                                .bill-header {
                                    text-align: center;
                                    margin-bottom: 10px;
                                }

                                .bill-header h2 {
                                    font-size: 16px;
                                    margin: 0;
                                    font-weight: bold;
                                }

                                .bill-header p {
                                    margin: 3px 0;
                                    font-size: 12px;
                                }

                                .bill-items {
                                    width: 100%;
                                    border-collapse: collapse;
                                    margin: 10px 0;
                                }

                                .bill-items th,
                                .bill-items td {
                                    text-align: left;
                                    padding: 3px 0;
                                }

                                .bill-items .amount {
                                    text-align: right;
                                }

                                .bill-total {
                                    border-top: 1px dashed #000;
                                    margin-top: 10px;
                                    padding-top: 5px;
                                }

                                .bill-total p {
                                    display: flex;
                                    justify-content: space-between;
                                    margin: 3px 0;
                                }

                                .bill-footer {
                                    text-align: center;
                                    margin-top: 15px;
                                    font-size: 11px;
                                }

                                .bill-footer p {
                                    margin: 3px 0;
                                }

                                .separator {
                                    border-top: 1px dashed #000;
                                    margin: 10px 0;
                                }

                                .no-print {
                                    display: none;
                                }
                            }
                        </style>
                    </head>
                    <body>
                        <div class="print-area">
                            <div class="bill-header">
                                <h2>AL MISBAH TRADING</h2>
                                <p>Building Materials & Hardware</p>
                                <p>Wholesale & Retail</p>
                                <p>TRN: 100534080700003</p>
                                <p>Tel: +971 6 5344330</p>
                                <p>Sharjah, United Arab Emirates</p>
                            </div>
                            <div class="separator"></div>
                            <div class="transaction-info">
                                <p><strong>Bill Number:</strong> ${invoiceNumber}</p>
                                <p><strong>Date:</strong> ${new Date(sale.date).toLocaleDateString()}</p>
                                <p><strong>Time:</strong> ${new Date(sale.date).toLocaleTimeString()}</p>
                            </div>
                            <div class="separator"></div>
                            <table class="bill-items">
                                <thead>
                                    <tr>
                                        <th>Item</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${sale.items.map(item => `
                                        <tr>
                                            <td>${item.name}</td>
                                            <td>${item.quantity}</td>
                                            <td>${Utils.formatCurrency(item.price)}</td>
                                            <td>${Utils.formatCurrency(item.total)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                            <div class="separator"></div>
                            <div class="bill-total">
                                <p>
                                    <span>Total Amount:</span>
                                    <span>${Utils.formatCurrency(sale.total)}</span>
                                </p>
                            </div>
                            <div class="separator"></div>
                            <div class="bill-footer">
                                <p>Thank you for your business!</p>
                                <p>Please visit again</p>
                            </div>
                        </div>
                        <div class="no-print">
                            <button onclick="window.print()">Print</button>
                        </div>
                    </body>
                    </html>
                `);
            };

            request.onerror = (event) => {
                console.error('Error fetching transaction:', event.target.error);
                Utils.showToast('Error printing transaction', 'error');
            };
        } catch (error) {
            console.error('Error printing transaction:', error);
            Utils.showToast('Error printing transaction', 'error');
        }
    }

    printReport() {
        window.print();
    }
}

// Initialize reports manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.reportsManager = new ReportsManager();
});
