// Database configuration
const DB_CONFIG = {
    name: 'pos_system',
    version: 1,
    stores: {
        inventory: {
            keyPath: 'code',
            indexes: [
                { name: 'name', unique: false },
                { name: 'category', unique: false }
            ]
        },
        quotations: {
            keyPath: 'quotationNumber',
            indexes: [
                { name: 'date', unique: false },
                { name: 'clientName', unique: false }
            ]
        },
        deliveries: {
            keyPath: 'deliveryNumber',
            indexes: [
                { name: 'date', unique: false },
                { name: 'status', unique: false }
            ]
        },
        clients: {
            keyPath: 'id',
            indexes: [
                { name: 'name', unique: false },
                { name: 'email', unique: false }
            ]
        }
    }
};

// Initialize database
function initDatabase() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_CONFIG.name, DB_CONFIG.version);

        request.onerror = () => {
            reject(new Error('Failed to open database'));
        };

        request.onsuccess = (event) => {
            const db = event.target.result;
            window.posDB = db;
            resolve(db);
        };

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            
            // Create object stores and indexes
            Object.entries(DB_CONFIG.stores).forEach(([storeName, config]) => {
                if (!db.objectStoreNames.contains(storeName)) {
                    const store = db.createObjectStore(storeName, { keyPath: config.keyPath });
                    
                    // Create indexes
                    config.indexes.forEach(index => {
                        store.createIndex(index.name, index.name, { unique: index.unique });
                    });
                }
            });
        };
    });
}

// Database helper functions
const DB = {
    // Get all records from a store
    getAll(storeName) {
        return new Promise((resolve, reject) => {
            const transaction = window.posDB.transaction(storeName, 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    // Get a single record by key
    get(storeName, key) {
        return new Promise((resolve, reject) => {
            const transaction = window.posDB.transaction(storeName, 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.get(key);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    // Add a new record
    add(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = window.posDB.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.add(data);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    // Update a record
    put(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = window.posDB.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.put(data);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    // Delete a record
    delete(storeName, key) {
        return new Promise((resolve, reject) => {
            const transaction = window.posDB.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.delete(key);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    // Query by index
    getByIndex(storeName, indexName, value) {
        return new Promise((resolve, reject) => {
            const transaction = window.posDB.transaction(storeName, 'readonly');
            const store = transaction.objectStore(storeName);
            const index = store.index(indexName);
            const request = index.getAll(value);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
};

// Export database functions
window.DB = DB;
window.initDatabase = initDatabase;
